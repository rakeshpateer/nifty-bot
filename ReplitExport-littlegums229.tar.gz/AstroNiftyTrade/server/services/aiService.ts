import OpenAI from "openai";
import type { MarketData, CrowdVote, MemeAnalysis, InsertTrade } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "demo-key" 
});

interface PredictionContext {
  marketData?: MarketData;
  crowdVotes: CrowdVote[];
  memeAnalysis?: MemeAnalysis;
}

interface AIPrediction {
  direction: 'up' | 'down';
  confidence: number;
  reasoning: string;
}

interface AITradeStory {
  story: string;
  confidence: number;
  lesson: string;
}

class AIService {
  async generatePrediction(symbol: string, context: PredictionContext): Promise<AIPrediction> {
    try {
      const prompt = `
        As an AI trading assistant, analyze the following data for ${symbol} and provide a prediction:
        
        Market Data: ${context.marketData ? JSON.stringify(context.marketData) : 'Not available'}
        Crowd Votes: ${context.crowdVotes.length} total votes
        Up votes: ${context.crowdVotes.filter(v => v.direction === 'up').length}
        Down votes: ${context.crowdVotes.filter(v => v.direction === 'down').length}
        Meme Analysis: ${context.memeAnalysis ? JSON.stringify(context.memeAnalysis) : 'Not available'}
        
        Provide your prediction in JSON format with:
        {
          "direction": "up" or "down",
          "confidence": number between 1-100,
          "reasoning": "detailed explanation of your analysis"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025
        messages: [
          {
            role: "system",
            content: "You are an expert AI trading analyst. Provide realistic, well-reasoned predictions based on market data, crowd sentiment, and meme analysis. Always respond in valid JSON format."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return {
        direction: result.direction || 'up',
        confidence: Math.max(1, Math.min(100, result.confidence || 75)),
        reasoning: result.reasoning || 'Analysis completed'
      };
    } catch (error) {
      console.error('AI prediction error:', error);
      // Fallback prediction
      return {
        direction: Math.random() > 0.5 ? 'up' : 'down',
        confidence: Math.floor(Math.random() * 30) + 70,
        reasoning: 'Fallback analysis due to AI service error'
      };
    }
  }

  async generateTradeStory(trade: InsertTrade): Promise<AITradeStory> {
    try {
      const prompt = `
        Generate an educational story explaining this trade decision:
        
        Trade: ${trade.type.toUpperCase()} ${trade.quantity} shares of ${trade.symbol} at ₹${trade.price}
        
        Create a compelling narrative that explains:
        1. The reasoning behind this trade
        2. What market factors influenced the decision
        3. A valuable lesson for retail traders
        
        Make it engaging but educational. Respond in JSON format:
        {
          "story": "narrative explanation",
          "confidence": number between 1-100,
          "lesson": "key takeaway for traders"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025
        messages: [
          {
            role: "system", 
            content: "You are a wise trading mentor. Create educational stories about trades that help retail investors learn. Keep stories realistic and include market psychology insights."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return {
        story: result.story || `Executed ${trade.type} order for ${trade.symbol} based on technical analysis.`,
        confidence: Math.max(1, Math.min(100, result.confidence || 80)),
        lesson: result.lesson || 'Always have a clear strategy before entering trades.'
      };
    } catch (error) {
      console.error('AI story generation error:', error);
      return {
        story: `Executed ${trade.type} order for ${trade.symbol} at ₹${trade.price}. This trade was based on technical analysis and risk management principles.`,
        confidence: 75,
        lesson: 'Consistent execution of trading strategy is key to long-term success.'
      };
    }
  }

  async generateMemesSentiment(symbol: string): Promise<{ score: number; trending: string[] }> {
    try {
      const prompt = `
        Analyze current meme sentiment for ${symbol} stock.
        Generate realistic meme trends and viral content analysis.
        
        Respond in JSON format:
        {
          "score": number between 1-10 (virality score),
          "trending": ["array", "of", "trending", "hashtags"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025
        messages: [
          {
            role: "system",
            content: "You are a social media sentiment analyst. Generate realistic meme trends and hashtags for Indian stock market."
          },
          {
            role: "user", 
            content: prompt
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return {
        score: Math.max(1, Math.min(10, result.score || Math.random() * 10)),
        trending: result.trending || [`#${symbol}ToTheMoon`, `#${symbol}Rocket`]
      };
    } catch (error) {
      console.error('Meme sentiment error:', error);
      return {
        score: Math.random() * 10,
        trending: [`#${symbol}ToTheMoon`, `#${symbol}Bulls`]
      };
    }
  }
}

export const aiService = new AIService();
