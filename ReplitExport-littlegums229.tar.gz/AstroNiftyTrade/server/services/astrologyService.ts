class AstrologyService {
  private planetaryBodies = [
    'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Moon', 'Sun'
  ];

  private zodiacSigns = [
    'Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo',
    'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'
  ];

  private houses = [
    '1st House (Self)', '2nd House (Money)', '3rd House (Communication)',
    '4th House (Home)', '5th House (Creativity)', '6th House (Work)',
    '7th House (Partnership)', '8th House (Transformation)', '9th House (Philosophy)',
    '10th House (Career)', '11th House (Community)', '12th House (Spirituality)'
  ];

  async getCurrentAlignment(): Promise<{
    description: string;
    bullishFactor: number;
    accuracy: number;
  }> {
    try {
      // Simulate current planetary positions
      const primaryPlanet = this.planetaryBodies[Math.floor(Math.random() * this.planetaryBodies.length)];
      const secondaryPlanet = this.planetaryBodies[Math.floor(Math.random() * this.planetaryBodies.length)];
      const house = this.houses[Math.floor(Math.random() * this.houses.length)];
      const sign = this.zodiacSigns[Math.floor(Math.random() * this.zodiacSigns.length)];
      
      // Generate alignment type
      const alignmentTypes = ['conjunction', 'trine', 'square', 'opposition', 'sextile'];
      const alignmentType = alignmentTypes[Math.floor(Math.random() * alignmentTypes.length)];
      
      // Calculate market influence
      const bullishFactor = this.calculateMarketInfluence(alignmentType, primaryPlanet, house);
      
      // Historical accuracy (simulated based on "backtesting")
      const accuracy = this.getHistoricalAccuracy(primaryPlanet, alignmentType);
      
      const description = `${primaryPlanet} ${alignmentType} with ${secondaryPlanet} in ${house} - ${sign} influence`;
      
      return {
        description,
        bullishFactor,
        accuracy
      };
    } catch (error) {
      console.error('Astrology service error:', error);
      return {
        description: 'Venus conjunction with Jupiter - favorable for markets',
        bullishFactor: 0.65,
        accuracy: 64
      };
    }
  }

  private calculateMarketInfluence(alignment: string, planet: string, house: string): number {
    let influence = 0.5; // Neutral base
    
    // Alignment influence
    switch (alignment) {
      case 'conjunction':
        influence += 0.2;
        break;
      case 'trine':
        influence += 0.15;
        break;
      case 'sextile':
        influence += 0.1;
        break;
      case 'square':
        influence -= 0.1;
        break;
      case 'opposition':
        influence -= 0.15;
        break;
    }
    
    // Planet influence on markets (traditional astrology beliefs)
    switch (planet) {
      case 'Jupiter':
        influence += 0.1; // Expansion, growth
        break;
      case 'Venus':
        influence += 0.05; // Harmony, beauty, luxury goods
        break;
      case 'Mercury':
        influence += 0.08; // Communication, technology
        break;
      case 'Mars':
        influence -= 0.05; // Conflict, volatility
        break;
      case 'Saturn':
        influence -= 0.1; // Restriction, discipline
        break;
    }
    
    // House influence (simplified)
    if (house.includes('Money') || house.includes('Career')) {
      influence += 0.05;
    }
    
    return Math.max(0.1, Math.min(0.9, influence));
  }

  private getHistoricalAccuracy(planet: string, alignment: string): number {
    // Simulate "backtested" historical accuracy
    let baseAccuracy = 50; // 50% base (random chance)
    
    // Some planets traditionally considered more "reliable"
    switch (planet) {
      case 'Jupiter':
        baseAccuracy += 15;
        break;
      case 'Venus':
        baseAccuracy += 10;
        break;
      case 'Mercury':
        baseAccuracy += 8;
        break;
      case 'Saturn':
        baseAccuracy += 12; // Predictable patterns
        break;
      default:
        baseAccuracy += Math.random() * 10;
    }
    
    // Alignment reliability
    switch (alignment) {
      case 'conjunction':
        baseAccuracy += 8;
        break;
      case 'opposition':
        baseAccuracy += 6;
        break;
      default:
        baseAccuracy += Math.random() * 5;
    }
    
    // Add some randomness to simulate real-world variations
    baseAccuracy += (Math.random() - 0.5) * 10;
    
    return Math.round(Math.max(30, Math.min(80, baseAccuracy)));
  }

  async getPlanetaryCalendar(days: number = 7): Promise<Array<{
    date: string;
    events: string[];
    marketInfluence: 'bullish' | 'bearish' | 'neutral';
  }>> {
    const calendar = [];
    const today = new Date();
    
    for (let i = 0; i < days; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      const events = [];
      const eventChance = Math.random();
      
      if (eventChance < 0.3) {
        const planet = this.planetaryBodies[Math.floor(Math.random() * this.planetaryBodies.length)];
        const sign = this.zodiacSigns[Math.floor(Math.random() * this.zodiacSigns.length)];
        events.push(`${planet} enters ${sign}`);
      }
      
      if (eventChance < 0.2) {
        const planet1 = this.planetaryBodies[Math.floor(Math.random() * this.planetaryBodies.length)];
        const planet2 = this.planetaryBodies[Math.floor(Math.random() * this.planetaryBodies.length)];
        events.push(`${planet1} conjunct ${planet2}`);
      }
      
      const marketInfluence: 'bullish' | 'bearish' | 'neutral' = 
        Math.random() < 0.4 ? 'bullish' : 
        Math.random() < 0.7 ? 'neutral' : 'bearish';
      
      calendar.push({
        date: date.toISOString().split('T')[0],
        events,
        marketInfluence
      });
    }
    
    return calendar;
  }

  async getSectorInfluence(): Promise<Record<string, {
    influence: number;
    description: string;
  }>> {
    // Map sectors to planetary influences
    return {
      'Banking': {
        influence: 0.7,
        description: 'Jupiter in 2nd house favors financial sector'
      },
      'IT': {
        influence: 0.8,
        description: 'Mercury dominant - excellent for technology stocks'
      },
      'Pharma': {
        influence: 0.6,
        description: 'Moon influence supports healthcare sector'
      },
      'Auto': {
        influence: 0.5,
        description: 'Mars square Venus creates mixed signals for automotive'
      },
      'FMCG': {
        influence: 0.75,
        description: 'Venus trine Jupiter supports consumer goods'
      }
    };
  }
}

export const astrologyService = new AstrologyService();
