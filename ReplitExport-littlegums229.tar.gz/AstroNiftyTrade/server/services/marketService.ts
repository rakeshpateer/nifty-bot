import { storage } from "../storage";

class MarketService {
  private blackSwanIndicators = [
    'unusual_options_volume',
    'vix_spike',
    'correlation_breakdown',
    'liquidity_crunch',
    'news_sentiment_crash'
  ];

  async updateMarketPrices(): Promise<void> {
    try {
      const symbols = ['RELIANCE', 'HDFCBANK', 'INFY', 'ICICIBANK', 'TCS', 'BHARTIARTL', 'ITC', 'SBIN'];
      
      for (const symbol of symbols) {
        const currentData = await storage.getMarketData(symbol);
        if (currentData.length > 0) {
          const current = currentData[0];
          const currentPrice = parseFloat(current.price!);
          
          // Generate realistic price movement (-2% to +2%)
          const changePercent = (Math.random() - 0.5) * 4;
          const newPrice = currentPrice * (1 + changePercent / 100);
          
          await storage.updateMarketData(symbol, {
            price: newPrice.toFixed(2),
            change: changePercent.toFixed(2),
            volume: `${(Math.random() * 5 + 1).toFixed(1)}M`
          });
        }
      }
    } catch (error) {
      console.error('Market price update error:', error);
    }
  }

  async calculateBlackSwanProbability(symbol: string): Promise<number> {
    try {
      // Get market data for analysis
      const marketData = await storage.getMarketData(symbol);
      if (marketData.length === 0) return 5; // Default 5% probability

      const current = marketData[0];
      const changePercent = Math.abs(parseFloat(current.change!));
      
      // Base probability calculation
      let probability = 2; // Base 2% probability
      
      // Increase probability based on various factors
      if (changePercent > 3) probability += 5; // High volatility
      if (changePercent > 5) probability += 10; // Extreme volatility
      
      // Add some randomness for "black swan" detection
      probability += Math.random() * 8;
      
      // Simulate occasional spikes
      if (Math.random() < 0.05) { // 5% chance of high probability
        probability += Math.random() * 20;
      }
      
      return Math.min(50, Math.max(1, probability)); // Cap at 50%
    } catch (error) {
      console.error('Black swan calculation error:', error);
      return 5;
    }
  }

  async detectUnusualActivity(symbol: string): Promise<{
    detected: boolean;
    indicators: string[];
    severity: 'low' | 'medium' | 'high';
  }> {
    try {
      const activeIndicators: string[] = [];
      
      // Simulate detection logic
      const detectionChance = Math.random();
      
      if (detectionChance < 0.1) {
        activeIndicators.push('unusual_options_volume');
      }
      
      if (detectionChance < 0.05) {
        activeIndicators.push('vix_spike');
      }
      
      if (detectionChance < 0.03) {
        activeIndicators.push('correlation_breakdown');
      }
      
      const severity: 'low' | 'medium' | 'high' = 
        activeIndicators.length >= 3 ? 'high' :
        activeIndicators.length >= 2 ? 'medium' : 'low';
      
      return {
        detected: activeIndicators.length > 0,
        indicators: activeIndicators,
        severity
      };
    } catch (error) {
      console.error('Unusual activity detection error:', error);
      return {
        detected: false,
        indicators: [],
        severity: 'low'
      };
    }
  }

  async generateBlackSwanScenario(symbol: string): Promise<{
    scenario: string;
    probability: number;
    impact: number;
    mitigation: string[];
  }> {
    const scenarios = [
      {
        scenario: "Regulatory crackdown on sector",
        probability: 8,
        impact: -25,
        mitigation: ["Diversify across sectors", "Monitor regulatory news", "Set stop losses"]
      },
      {
        scenario: "Major accounting irregularity discovered",
        probability: 3,
        impact: -40,
        mitigation: ["Research financial statements", "Check auditor reputation", "Limit position size"]
      },
      {
        scenario: "Geopolitical tension affecting supply chain",
        probability: 12,
        impact: -15,
        mitigation: ["Monitor global news", "Hedge with defensive stocks", "Maintain cash reserves"]
      },
      {
        scenario: "Technology disruption threatening business model",
        probability: 15,
        impact: -30,
        mitigation: ["Research industry trends", "Invest in innovative companies", "Review quarterly results"]
      }
    ];
    
    return scenarios[Math.floor(Math.random() * scenarios.length)];
  }
}

export const marketService = new MarketService();
