import { 
  type User, 
  type InsertUser, 
  type Portfolio, 
  type InsertPortfolio,
  type Trade,
  type InsertTrade,
  type Prediction,
  type InsertPrediction,
  type CrowdVote,
  type InsertCrowdVote,
  type TopTrader,
  type InsertTopTrader,
  type MarketData,
  type InsertMarketData,
  type MemeAnalysis,
  type InsertMemeAnalysis
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Portfolio operations
  getPortfolio(userId: string): Promise<Portfolio[]>;
  getPortfolioBySymbol(userId: string, symbol: string): Promise<Portfolio | undefined>;
  createPortfolioEntry(portfolio: InsertPortfolio): Promise<Portfolio>;
  updatePortfolioEntry(id: string, updates: Partial<Portfolio>): Promise<Portfolio | undefined>;
  deletePortfolioEntry(id: string): Promise<boolean>;

  // Trade operations
  getTrades(userId: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined>;
  getActiveTradesBySymbol(symbol: string): Promise<Trade[]>;

  // Prediction operations
  getPredictions(symbol?: string): Promise<Prediction[]>;
  getLatestPrediction(symbol: string): Promise<Prediction | undefined>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;

  // Crowd voting operations
  getCrowdVotes(symbol: string, date: string): Promise<CrowdVote[]>;
  createCrowdVote(vote: InsertCrowdVote): Promise<CrowdVote>;
  getUserVote(userId: string, symbol: string, date: string): Promise<CrowdVote | undefined>;

  // Top traders operations
  getTopTraders(): Promise<TopTrader[]>;
  createTopTrader(trader: InsertTopTrader): Promise<TopTrader>;
  updateTopTrader(id: string, updates: Partial<TopTrader>): Promise<TopTrader | undefined>;

  // Market data operations
  getMarketData(symbol?: string): Promise<MarketData[]>;
  createMarketData(data: InsertMarketData): Promise<MarketData>;
  updateMarketData(symbol: string, updates: Partial<MarketData>): Promise<MarketData | undefined>;

  // Meme analysis operations
  getMemeAnalysis(symbol?: string): Promise<MemeAnalysis[]>;
  createMemeAnalysis(analysis: InsertMemeAnalysis): Promise<MemeAnalysis>;
  getLatestMemeAnalysis(symbol: string): Promise<MemeAnalysis | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private portfolios: Map<string, Portfolio> = new Map();
  private trades: Map<string, Trade> = new Map();
  private predictions: Map<string, Prediction> = new Map();
  private crowdVotes: Map<string, CrowdVote> = new Map();
  private topTraders: Map<string, TopTrader> = new Map();
  private marketData: Map<string, MarketData> = new Map();
  private memeAnalysis: Map<string, MemeAnalysis> = new Map();

  constructor() {
    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample user
    const sampleUser: User = {
      id: "user-1",
      username: "raj_patel",
      email: "raj@example.com",
      password: "hashed_password",
      portfolioValue: "1245670",
      charityFund: "3240",
      ethicalMode: true,
      createdAt: new Date(),
    };
    this.users.set("user-1", sampleUser);

    // Sample market data for major stocks
    const stockSymbols = [
      { symbol: "RELIANCE", price: "2847.50", change: "1.2" },
      { symbol: "HDFCBANK", price: "1672.30", change: "-0.8" },
      { symbol: "INFY", price: "1432.80", change: "2.1" },
      { symbol: "ICICIBANK", price: "1156.40", change: "0.5" },
      { symbol: "TCS", price: "3890.20", change: "-0.3" },
      { symbol: "BHARTIARTL", price: "1024.65", change: "1.8" },
      { symbol: "ITC", price: "456.75", change: "0.9" },
      { symbol: "SBIN", price: "825.30", change: "2.2" }
    ];

    stockSymbols.forEach((stock, index) => {
      const marketDataEntry: MarketData = {
        id: `market-${index}`,
        symbol: stock.symbol,
        price: stock.price,
        change: stock.change,
        volume: `${(Math.random() * 5 + 1).toFixed(1)}M`,
        marketCap: `₹${Math.floor(Math.random() * 500000 + 100000)}Cr`,
        updatedAt: new Date(),
      };
      this.marketData.set(stock.symbol, marketDataEntry);

      // Sample portfolio entries
      if (index < 5) {
        const portfolioEntry: Portfolio = {
          id: `portfolio-${index}`,
          userId: "user-1",
          symbol: stock.symbol,
          quantity: Math.floor(Math.random() * 100 + 10),
          averagePrice: (parseFloat(stock.price) * (0.9 + Math.random() * 0.2)).toFixed(2),
          currentPrice: stock.price,
          createdAt: new Date(),
        };
        this.portfolios.set(`portfolio-${index}`, portfolioEntry);
      }
    });

    // Sample top traders
    const sampleTraders = [
      { username: "TradeMaster_99", return: "47.2" },
      { username: "NiftyNinja", return: "32.8" },
      { username: "AITradeBot", return: "28.5" }
    ];

    sampleTraders.forEach((trader, index) => {
      const topTrader: TopTrader = {
        id: `trader-${index}`,
        userId: `trader-user-${index}`,
        username: trader.username,
        monthlyReturn: trader.return,
        followersCount: Math.floor(Math.random() * 1000 + 100),
        consentToClone: true,
        portfolioData: null,
        updatedAt: new Date(),
      };
      this.topTraders.set(`trader-${index}`, topTrader);
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      portfolioValue: insertUser.portfolioValue || "100000",
      charityFund: insertUser.charityFund || "0",
      ethicalMode: insertUser.ethicalMode ?? true,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Portfolio operations
  async getPortfolio(userId: string): Promise<Portfolio[]> {
    return Array.from(this.portfolios.values()).filter(p => p.userId === userId);
  }

  async getPortfolioBySymbol(userId: string, symbol: string): Promise<Portfolio | undefined> {
    return Array.from(this.portfolios.values()).find(p => p.userId === userId && p.symbol === symbol);
  }

  async createPortfolioEntry(insertPortfolio: InsertPortfolio): Promise<Portfolio> {
    const id = randomUUID();
    const portfolio: Portfolio = { 
      ...insertPortfolio, 
      id,
      createdAt: new Date()
    };
    this.portfolios.set(id, portfolio);
    return portfolio;
  }

  async updatePortfolioEntry(id: string, updates: Partial<Portfolio>): Promise<Portfolio | undefined> {
    const portfolio = this.portfolios.get(id);
    if (!portfolio) return undefined;
    const updatedPortfolio = { ...portfolio, ...updates };
    this.portfolios.set(id, updatedPortfolio);
    return updatedPortfolio;
  }

  async deletePortfolioEntry(id: string): Promise<boolean> {
    return this.portfolios.delete(id);
  }

  // Trade operations
  async getTrades(userId: string): Promise<Trade[]> {
    return Array.from(this.trades.values()).filter(t => t.userId === userId);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const trade: Trade = { 
      ...insertTrade, 
      id,
      status: insertTrade.status || "active",
      createdAt: new Date()
    };
    this.trades.set(id, trade);
    return trade;
  }

  async updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined> {
    const trade = this.trades.get(id);
    if (!trade) return undefined;
    const updatedTrade = { ...trade, ...updates };
    this.trades.set(id, updatedTrade);
    return updatedTrade;
  }

  async getActiveTradesBySymbol(symbol: string): Promise<Trade[]> {
    return Array.from(this.trades.values()).filter(t => t.symbol === symbol && t.status === "active");
  }

  // Prediction operations
  async getPredictions(symbol?: string): Promise<Prediction[]> {
    const predictions = Array.from(this.predictions.values());
    return symbol ? predictions.filter(p => p.symbol === symbol) : predictions;
  }

  async getLatestPrediction(symbol: string): Promise<Prediction | undefined> {
    const predictions = await this.getPredictions(symbol);
    return predictions.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())[0];
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const id = randomUUID();
    const prediction: Prediction = { 
      ...insertPrediction, 
      id,
      createdAt: new Date()
    };
    this.predictions.set(id, prediction);
    return prediction;
  }

  // Crowd voting operations
  async getCrowdVotes(symbol: string, date: string): Promise<CrowdVote[]> {
    return Array.from(this.crowdVotes.values()).filter(v => v.symbol === symbol && v.date === date);
  }

  async createCrowdVote(insertVote: InsertCrowdVote): Promise<CrowdVote> {
    const id = randomUUID();
    const vote: CrowdVote = { 
      ...insertVote, 
      id,
      createdAt: new Date()
    };
    this.crowdVotes.set(id, vote);
    return vote;
  }

  async getUserVote(userId: string, symbol: string, date: string): Promise<CrowdVote | undefined> {
    return Array.from(this.crowdVotes.values()).find(v => 
      v.userId === userId && v.symbol === symbol && v.date === date
    );
  }

  // Top traders operations
  async getTopTraders(): Promise<TopTrader[]> {
    return Array.from(this.topTraders.values()).sort((a, b) => 
      parseFloat(b.monthlyReturn!) - parseFloat(a.monthlyReturn!)
    );
  }

  async createTopTrader(insertTrader: InsertTopTrader): Promise<TopTrader> {
    const id = randomUUID();
    const trader: TopTrader = { 
      ...insertTrader, 
      id,
      followersCount: insertTrader.followersCount || 0,
      consentToClone: insertTrader.consentToClone ?? false,
      updatedAt: new Date()
    };
    this.topTraders.set(id, trader);
    return trader;
  }

  async updateTopTrader(id: string, updates: Partial<TopTrader>): Promise<TopTrader | undefined> {
    const trader = this.topTraders.get(id);
    if (!trader) return undefined;
    const updatedTrader = { ...trader, ...updates, updatedAt: new Date() };
    this.topTraders.set(id, updatedTrader);
    return updatedTrader;
  }

  // Market data operations
  async getMarketData(symbol?: string): Promise<MarketData[]> {
    const data = Array.from(this.marketData.values());
    return symbol ? data.filter(d => d.symbol === symbol) : data;
  }

  async createMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const id = randomUUID();
    const data: MarketData = { 
      ...insertData, 
      id,
      updatedAt: new Date()
    };
    this.marketData.set(insertData.symbol, data);
    return data;
  }

  async updateMarketData(symbol: string, updates: Partial<MarketData>): Promise<MarketData | undefined> {
    const data = this.marketData.get(symbol);
    if (!data) return undefined;
    const updatedData = { ...data, ...updates, updatedAt: new Date() };
    this.marketData.set(symbol, updatedData);
    return updatedData;
  }

  // Meme analysis operations
  async getMemeAnalysis(symbol?: string): Promise<MemeAnalysis[]> {
    const analysis = Array.from(this.memeAnalysis.values());
    return symbol ? analysis.filter(a => a.symbol === symbol) : analysis;
  }

  async createMemeAnalysis(insertAnalysis: InsertMemeAnalysis): Promise<MemeAnalysis> {
    const id = randomUUID();
    const analysis: MemeAnalysis = { 
      ...insertAnalysis, 
      id,
      createdAt: new Date()
    };
    this.memeAnalysis.set(id, analysis);
    return analysis;
  }

  async getLatestMemeAnalysis(symbol: string): Promise<MemeAnalysis | undefined> {
    const analyses = await this.getMemeAnalysis(symbol);
    return analyses.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())[0];
  }
}

export const storage = new MemStorage();
