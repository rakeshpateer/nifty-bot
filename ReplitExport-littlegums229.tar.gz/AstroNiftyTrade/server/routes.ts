import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertCrowdVoteSchema, insertTradeSchema } from "@shared/schema";
import { aiService } from "./services/aiService";
import { marketService } from "./services/marketService";
import { astrologyService } from "./services/astrologyService";
import { sentimentService } from "./services/sentimentService";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const connectedClients = new Set<WebSocket>();

  wss.on('connection', (ws: WebSocket) => {
    connectedClients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      connectedClients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });

    // Send initial market data
    ws.send(JSON.stringify({
      type: 'market_update',
      data: 'Connected to NiftyAI real-time updates'
    }));
  });

  // Broadcast function for real-time updates
  const broadcast = (message: any) => {
    const data = JSON.stringify(message);
    connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  };

  // API Routes

  // Dashboard data
  app.get('/api/dashboard', async (req, res) => {
    try {
      const userId = 'user-1'; // In real app, get from session
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const portfolio = await storage.getPortfolio(userId);
      const trades = await storage.getTrades(userId);
      const marketData = await storage.getMarketData();

      res.json({
        user,
        portfolio,
        trades: trades.filter(t => t.status === 'active'),
        marketData: marketData.slice(0, 8) // Top 8 stocks
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch dashboard data' });
    }
  });

  // Market data
  app.get('/api/market/:symbol?', async (req, res) => {
    try {
      const { symbol } = req.params;
      const marketData = await storage.getMarketData(symbol);
      res.json(marketData);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch market data' });
    }
  });

  // AI Predictions
  app.get('/api/predictions/:symbol?', async (req, res) => {
    try {
      const { symbol } = req.params;
      let predictions;
      
      if (symbol) {
        const prediction = await storage.getLatestPrediction(symbol);
        predictions = prediction ? [prediction] : [];
      } else {
        predictions = await storage.getPredictions();
      }

      res.json(predictions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch predictions' });
    }
  });

  // Generate AI prediction
  app.post('/api/predictions/generate/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      
      // Get market data and other factors
      const marketData = await storage.getMarketData(symbol);
      const crowdVotes = await storage.getCrowdVotes(symbol, new Date().toISOString().split('T')[0]);
      const memeAnalysis = await storage.getLatestMemeAnalysis(symbol);
      
      // Generate AI prediction
      const aiPrediction = await aiService.generatePrediction(symbol, {
        marketData: marketData[0],
        crowdVotes,
        memeAnalysis
      });

      // Get astrology and other factors
      const astrologyFactor = await astrologyService.getCurrentAlignment();
      const weatherMoodIndex = await sentimentService.getWeatherMoodIndex();
      const blackSwanProbability = await marketService.calculateBlackSwanProbability(symbol);

      const prediction = await storage.createPrediction({
        symbol,
        direction: aiPrediction.direction,
        confidence: aiPrediction.confidence,
        blackSwanProbability: blackSwanProbability.toString(),
        astrologyFactor: astrologyFactor.description,
        weatherMoodIndex: weatherMoodIndex.toString(),
        memeScore: memeAnalysis?.viralityScore || "0",
        crowdSentiment: crowdVotes.length > 0 ? 
          (crowdVotes.filter(v => v.direction === 'up').length / crowdVotes.length * 100).toFixed(2) : "50"
      });

      // Broadcast to connected clients
      broadcast({
        type: 'prediction_update',
        data: prediction
      });

      res.json(prediction);
    } catch (error) {
      console.error('Failed to generate prediction:', error);
      res.status(500).json({ message: 'Failed to generate AI prediction' });
    }
  });

  // Crowd voting
  app.get('/api/crowd-votes/:symbol/:date', async (req, res) => {
    try {
      const { symbol, date } = req.params;
      const votes = await storage.getCrowdVotes(symbol, date);
      
      const upVotes = votes.filter(v => v.direction === 'up').length;
      const downVotes = votes.filter(v => v.direction === 'down').length;
      const total = upVotes + downVotes;

      res.json({
        upVotes,
        downVotes,
        total,
        upPercentage: total > 0 ? Math.round((upVotes / total) * 100) : 50
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch crowd votes' });
    }
  });

  app.post('/api/crowd-votes', async (req, res) => {
    try {
      const voteData = insertCrowdVoteSchema.parse(req.body);
      
      // Check if user already voted today
      const existingVote = await storage.getUserVote(voteData.userId, voteData.symbol, voteData.date);
      if (existingVote) {
        return res.status(400).json({ message: 'You have already voted today' });
      }

      const vote = await storage.createCrowdVote(voteData);

      // Broadcast updated vote count
      const votes = await storage.getCrowdVotes(voteData.symbol, voteData.date);
      const upVotes = votes.filter(v => v.direction === 'up').length;
      const total = votes.length;

      broadcast({
        type: 'vote_update',
        data: {
          symbol: voteData.symbol,
          upPercentage: Math.round((upVotes / total) * 100),
          total
        }
      });

      res.json(vote);
    } catch (error) {
      res.status(400).json({ message: 'Failed to submit vote' });
    }
  });

  // Trading operations
  app.post('/api/trades', async (req, res) => {
    try {
      const tradeData = insertTradeSchema.parse(req.body);
      
      // Generate AI story for the trade
      const aiStory = await aiService.generateTradeStory(tradeData);
      
      const trade = await storage.createTrade({
        ...tradeData,
        aiStory: aiStory.story,
        aiConfidence: aiStory.confidence
      });

      broadcast({
        type: 'trade_update',
        data: trade
      });

      res.json(trade);
    } catch (error) {
      console.error('Failed to create trade:', error);
      res.status(400).json({ message: 'Failed to create trade' });
    }
  });

  // Panic button - halt all trades and convert to gold
  app.post('/api/panic/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Get all active trades
      const trades = await storage.getTrades(userId);
      const activeTrades = trades.filter(t => t.status === 'active');
      
      // Cancel all active trades
      for (const trade of activeTrades) {
        await storage.updateTrade(trade.id, { status: 'cancelled' });
      }

      // Get user's portfolio value
      const user = await storage.getUser(userId);
      if (user) {
        const portfolioValue = parseFloat(user.portfolioValue || "0");
        const goldAllocation = portfolioValue * 0.5; // 50% to gold

        // Create gold ETF position (simulated)
        await storage.createPortfolioEntry({
          userId,
          symbol: 'GOLDETF',
          quantity: Math.floor(goldAllocation / 5000), // Assume gold ETF @ ₹5000
          averagePrice: "5000",
          currentPrice: "5000"
        });

        // Update user portfolio value
        await storage.updateUser(userId, {
          portfolioValue: (portfolioValue * 0.5).toFixed(2) // Remaining 50%
        });
      }

      broadcast({
        type: 'panic_activated',
        data: {
          userId,
          cancelledTrades: activeTrades.length,
          message: 'Panic mode activated - All trades halted, 50% converted to Gold ETF'
        }
      });

      res.json({
        message: 'Panic mode activated successfully',
        cancelledTrades: activeTrades.length
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to activate panic mode' });
    }
  });

  // Top traders
  app.get('/api/top-traders', async (req, res) => {
    try {
      const topTraders = await storage.getTopTraders();
      res.json(topTraders.slice(0, 5)); // Top 5 traders
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch top traders' });
    }
  });

  // Clone trader portfolio
  app.post('/api/clone-trader/:traderId', async (req, res) => {
    try {
      const { traderId } = req.params;
      const { userId } = req.body;

      const trader = await storage.getTopTraders().then(traders => 
        traders.find(t => t.id === traderId)
      );

      if (!trader || !trader.consentToClone) {
        return res.status(400).json({ message: 'Trader not found or cloning not allowed' });
      }

      broadcast({
        type: 'portfolio_cloned',
        data: {
          userId,
          traderId,
          traderName: trader.username
        }
      });

      res.json({ message: `Successfully cloned ${trader.username}'s portfolio` });
    } catch (error) {
      res.status(500).json({ message: 'Failed to clone trader portfolio' });
    }
  });

  // Meme sentiment analysis
  app.get('/api/meme-analysis/:symbol?', async (req, res) => {
    try {
      const { symbol } = req.params;
      const analysis = await storage.getMemeAnalysis(symbol);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch meme analysis' });
    }
  });

  // Weather mood index
  app.get('/api/weather-mood', async (req, res) => {
    try {
      const mumbaiWeather = await sentimentService.getMumbaiWeatherMood();
      const bangaloreWeather = await sentimentService.getBangaloreWeatherMood();
      
      res.json({
        mumbai: mumbaiWeather,
        bangalore: bangaloreWeather,
        correlation: 0.67 // Historical correlation
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch weather mood data' });
    }
  });

  // Start background services
  setInterval(async () => {
    try {
      // Update market data every 30 seconds
      await marketService.updateMarketPrices();
      
      // Generate predictions every 5 minutes
      const symbols = ['RELIANCE', 'HDFCBANK', 'INFY'];
      for (const symbol of symbols) {
        // Generate AI prediction and broadcast
      }
    } catch (error) {
      console.error('Background update error:', error);
    }
  }, 30000);

  return httpServer;
}
