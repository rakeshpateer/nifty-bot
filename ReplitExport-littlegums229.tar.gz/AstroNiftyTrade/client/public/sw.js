const CACHE_NAME = 'niftyai-v1.0.0';
const STATIC_CACHE_NAME = 'niftyai-static-v1.0.0';
const DYNAMIC_CACHE_NAME = 'niftyai-dynamic-v1.0.0';

// Files to cache for offline functionality
const STATIC_FILES = [
  '/',
  '/dashboard',
  '/manifest.json',
  '/static/js/bundle.js',
  '/static/css/main.css',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'
];

// API endpoints that should be cached
const API_CACHE_ENDPOINTS = [
  '/api/dashboard',
  '/api/market',
  '/api/predictions',
  '/api/top-traders',
  '/api/weather-mood'
];

// Install event - cache static files
self.addEventListener('install', event => {
  console.log('NiftyAI Service Worker: Installing...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then(cache => {
        console.log('NiftyAI Service Worker: Caching static files');
        return cache.addAll(STATIC_FILES);
      })
      .then(() => {
        console.log('NiftyAI Service Worker: Installation complete');
        return self.skipWaiting();
      })
      .catch(error => {
        console.error('NiftyAI Service Worker: Installation failed', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('NiftyAI Service Worker: Activating...');
  
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== STATIC_CACHE_NAME && 
                cacheName !== DYNAMIC_CACHE_NAME &&
                cacheName.startsWith('niftyai-')) {
              console.log('NiftyAI Service Worker: Deleting old cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('NiftyAI Service Worker: Activation complete');
        return self.clients.claim();
      })
  );
});

// Fetch event - handle network requests with caching strategy
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip WebSocket connections
  if (url.pathname === '/ws') {
    return;
  }
  
  // Handle API requests with network-first strategy for real-time data
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(handleApiRequest(request));
    return;
  }
  
  // Handle static files with cache-first strategy
  if (STATIC_FILES.some(file => url.pathname === file || url.pathname.startsWith(file))) {
    event.respondWith(handleStaticRequest(request));
    return;
  }
  
  // Handle navigation requests
  if (request.mode === 'navigate') {
    event.respondWith(handleNavigationRequest(request));
    return;
  }
  
  // Default: try network first, then cache
  event.respondWith(
    fetch(request)
      .then(response => {
        // Clone response for caching
        const responseClone = response.clone();
        
        // Cache successful responses
        if (response.status === 200) {
          caches.open(DYNAMIC_CACHE_NAME)
            .then(cache => cache.put(request, responseClone));
        }
        
        return response;
      })
      .catch(() => {
        // Fallback to cache
        return caches.match(request);
      })
  );
});

// Handle API requests with network-first strategy
async function handleApiRequest(request) {
  const url = new URL(request.url);
  
  try {
    // Try network first for real-time data
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      // Cache successful API responses for offline access
      const cache = await caches.open(DYNAMIC_CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.log('NiftyAI Service Worker: Network failed for API, trying cache', url.pathname);
    
    // Fallback to cache
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
      // Add offline indicator to cached API responses
      const response = cachedResponse.clone();
      const data = await response.json();
      
      return new Response(JSON.stringify({
        ...data,
        _offline: true,
        _lastUpdated: new Date().toISOString()
      }), {
        headers: {
          'Content-Type': 'application/json',
          'X-Offline-Data': 'true'
        }
      });
    }
    
    // Return offline fallback data
    return new Response(JSON.stringify({
      error: 'Offline - No cached data available',
      _offline: true
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Handle static files with cache-first strategy
async function handleStaticRequest(request) {
  try {
    // Try cache first
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Fallback to network
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(STATIC_CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('NiftyAI Service Worker: Failed to fetch static file', request.url);
    throw error;
  }
}

// Handle navigation requests
async function handleNavigationRequest(request) {
  try {
    // Try network first
    const networkResponse = await fetch(request);
    return networkResponse;
  } catch (error) {
    // Fallback to cached index.html for SPA routing
    const cachedResponse = await caches.match('/');
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Ultimate fallback
    return new Response(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>NiftyAI - Offline</title>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body { 
              font-family: Inter, sans-serif; 
              background: #1e1b2e; 
              color: #e2e8f0; 
              text-align: center; 
              padding: 2rem; 
            }
            .offline-message { 
              max-width: 400px; 
              margin: 2rem auto; 
              padding: 2rem; 
              border: 1px solid #334155; 
              border-radius: 8px; 
            }
            .logo { color: #00d2ff; font-size: 2rem; font-weight: bold; }
            .retry-btn {
              background: #00d2ff;
              color: #1e1b2e;
              border: none;
              padding: 0.75rem 1.5rem;
              border-radius: 6px;
              cursor: pointer;
              margin-top: 1rem;
            }
          </style>
        </head>
        <body>
          <div class="offline-message">
            <div class="logo">NiftyAI</div>
            <h2>You're Offline</h2>
            <p>Connect to the internet to access real-time trading data and AI predictions.</p>
            <button class="retry-btn" onclick="window.location.reload()">Retry</button>
          </div>
        </body>
      </html>
    `, {
      headers: { 'Content-Type': 'text/html' }
    });
  }
}

// Background sync for queued actions when back online
self.addEventListener('sync', event => {
  console.log('NiftyAI Service Worker: Background sync triggered', event.tag);
  
  if (event.tag === 'trade-queue') {
    event.waitUntil(processPendingTrades());
  }
  
  if (event.tag === 'vote-queue') {
    event.waitUntil(processPendingVotes());
  }
});

// Process pending trades when back online
async function processPendingTrades() {
  try {
    const pendingTrades = await getStoredData('pending-trades');
    
    for (const trade of pendingTrades) {
      try {
        await fetch('/api/trades', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(trade)
        });
        
        // Remove processed trade
        await removeStoredData('pending-trades', trade.id);
      } catch (error) {
        console.error('Failed to process pending trade:', error);
      }
    }
  } catch (error) {
    console.error('Error processing pending trades:', error);
  }
}

// Process pending votes when back online
async function processPendingVotes() {
  try {
    const pendingVotes = await getStoredData('pending-votes');
    
    for (const vote of pendingVotes) {
      try {
        await fetch('/api/crowd-votes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(vote)
        });
        
        // Remove processed vote
        await removeStoredData('pending-votes', vote.id);
      } catch (error) {
        console.error('Failed to process pending vote:', error);
      }
    }
  } catch (error) {
    console.error('Error processing pending votes:', error);
  }
}

// Push notifications for trade alerts
self.addEventListener('push', event => {
  console.log('NiftyAI Service Worker: Push notification received');
  
  const options = {
    body: 'You have new trading alerts',
    icon: '/icon-192x192.png',
    badge: '/badge-72x72.png',
    vibrate: [200, 100, 200],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'view-dashboard',
        title: 'View Dashboard',
        icon: '/action-dashboard.png'
      },
      {
        action: 'dismiss',
        title: 'Dismiss',
        icon: '/action-dismiss.png'
      }
    ]
  };
  
  if (event.data) {
    try {
      const payload = event.data.json();
      options.body = payload.message || options.body;
      options.data = { ...options.data, ...payload };
    } catch (error) {
      console.error('Error parsing push notification data:', error);
    }
  }
  
  event.waitUntil(
    self.registration.showNotification('NiftyAI Trading Alert', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  console.log('NiftyAI Service Worker: Notification clicked');
  
  event.notification.close();
  
  if (event.action === 'view-dashboard') {
    event.waitUntil(
      clients.openWindow('/dashboard')
    );
  } else if (event.action === 'dismiss') {
    // Just close the notification
    return;
  } else {
    // Default action - open app
    event.waitUntil(
      clients.matchAll({ type: 'window' })
        .then(clientList => {
          // Focus existing window if available
          for (const client of clientList) {
            if (client.url === '/' && 'focus' in client) {
              return client.focus();
            }
          }
          
          // Open new window
          if (clients.openWindow) {
            return clients.openWindow('/');
          }
        })
    );
  }
});

// Utility functions for IndexedDB storage
async function getStoredData(storeName) {
  // Implementation would use IndexedDB to retrieve pending data
  // For now, return empty array
  return [];
}

async function removeStoredData(storeName, id) {
  // Implementation would use IndexedDB to remove processed data
  console.log(`Removing ${id} from ${storeName}`);
}

// Message handling for communication with main thread
self.addEventListener('message', event => {
  console.log('NiftyAI Service Worker: Message received', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});

console.log('NiftyAI Service Worker: Script loaded');
