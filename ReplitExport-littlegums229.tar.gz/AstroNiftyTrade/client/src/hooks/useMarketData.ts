import { useQuery } from "@tanstack/react-query";

export function useMarketData(symbol?: string) {
  return useQuery({
    queryKey: symbol ? ['/api/market', symbol] : ['/api/market'],
    refetchInterval: 30000, // Refetch every 30 seconds
    refetchIntervalInBackground: true,
  });
}
