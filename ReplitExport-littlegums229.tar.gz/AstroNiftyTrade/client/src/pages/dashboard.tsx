import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import PortfolioOverview from "@/components/PortfolioOverview";
import MarketChart from "@/components/MarketChart";
import StockWatchlist from "@/components/StockWatchlist";
import CrowdPrediction from "@/components/CrowdPrediction";
import AIStorytelling from "@/components/AIStorytelling";
import MemesentimentAnalyzer from "@/components/MemesentimentAnalyzer";
import AstroTracker from "@/components/AstroTracker";
import TopTraders from "@/components/TopTraders";
import WeatherMoodIndex from "@/components/WeatherMoodIndex";
import PanicButton from "@/components/PanicButton";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Dashboard() {
  const [showDisclaimer, setShowDisclaimer] = useState(true);
  const { data: dashboardData, isLoading, error } = useQuery({
    queryKey: ['/api/dashboard'],
  });

  // WebSocket connection for real-time updates
  const { isConnected, lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      console.log('Real-time update:', lastMessage);
      // Handle real-time updates here
    }
  }, [lastMessage]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading NiftyAI Dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Dashboard Error</h1>
          <p className="text-muted-foreground">Failed to load dashboard data. Please try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Connection Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-success animate-pulse' : 'bg-destructive'}`}></div>
            <span className="text-sm text-muted-foreground">
              {isConnected ? 'Connected to real-time updates' : 'Disconnected'}
            </span>
          </div>
          <PanicButton userId="user-1" />
        </div>

        {/* Portfolio Overview */}
        <PortfolioOverview data={dashboardData} />

        {/* Main Trading Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Market Charts */}
          <div className="lg:col-span-2 space-y-6">
            <MarketChart marketData={dashboardData?.marketData} />
            <AIStorytelling trades={dashboardData?.trades} />
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            <CrowdPrediction symbol="NIFTY" />
            <TopTraders />
            <WeatherMoodIndex />
          </div>
        </div>

        {/* Stock Watchlist */}
        <StockWatchlist marketData={dashboardData?.marketData} />

        {/* AI Storytelling & Astro Tracker */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AstroTracker />
          <MemesentimentAnalyzer />
        </div>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3" data-testid="floating-actions">
        <Button 
          size="icon" 
          className="w-14 h-14 rounded-full bg-primary hover:bg-primary/80 shadow-lg"
          data-testid="button-quick-trade"
        >
          <i className="fas fa-bolt text-lg"></i>
        </Button>
        <Button 
          size="icon" 
          className="w-14 h-14 rounded-full bg-accent hover:bg-accent/80 shadow-lg"
          data-testid="button-ai-insights"
        >
          <i className="fas fa-brain text-lg"></i>
        </Button>
        <Button 
          size="icon" 
          className="w-14 h-14 rounded-full bg-success hover:bg-success/80 shadow-lg"
          data-testid="button-portfolio-analysis"
        >
          <i className="fas fa-chart-pie text-lg"></i>
        </Button>
      </div>

      {/* Disclaimer Modal */}
      <Dialog open={showDisclaimer} onOpenChange={setShowDisclaimer}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center text-destructive">
              <AlertTriangle className="mr-3" />
              EXPERIMENTAL TRADING PLATFORM
            </DialogTitle>
            <DialogDescription className="space-y-4 text-muted-foreground">
              <p className="font-medium text-foreground">⚠️ IMPORTANT DISCLAIMER:</p>
              <ul className="space-y-2 text-sm list-disc list-inside">
                <li>This is an EXPERIMENTAL platform combining AI predictions with unconventional factors</li>
                <li>Astrology-based predictions are for educational/entertainment purposes only</li>
                <li>Meme sentiment analysis is experimental and not financial advice</li>
                <li>Black swan simulation uses synthetic data - actual market behavior may differ</li>
                <li>All trading decisions should be made with proper risk management</li>
                <li>Platform is SEBI-compliant but features are experimental in nature</li>
                <li>Past performance does not guarantee future results</li>
                <li>Please consult with qualified financial advisors before making investment decisions</li>
              </ul>
              <div className="bg-destructive/20 p-4 rounded-lg border border-destructive/30">
                <p className="text-destructive font-medium text-sm">
                  Trade responsibly. This platform is designed for educational purposes and experimental trading strategies. 
                  Never invest more than you can afford to lose.
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={() => setShowDisclaimer(false)} data-testid="button-understand">
              I Understand
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
