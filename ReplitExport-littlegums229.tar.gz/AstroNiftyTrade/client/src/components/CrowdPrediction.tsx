import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CrowdPredictionProps {
  symbol: string;
}

export default function CrowdPrediction({ symbol }: CrowdPredictionProps) {
  const [hasVoted, setHasVoted] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = new Date().toISOString().split('T')[0];

  const { data: voteData, isLoading } = useQuery({
    queryKey: [`/api/crowd-votes/${symbol}/${today}`],
  });

  const voteMutation = useMutation({
    mutationFn: async (direction: 'up' | 'down') => {
      return apiRequest('POST', '/api/crowd-votes', {
        userId: 'user-1', // In real app, get from auth
        symbol,
        direction,
        date: today
      });
    },
    onSuccess: () => {
      setHasVoted(true);
      queryClient.invalidateQueries({ queryKey: [`/api/crowd-votes/${symbol}/${today}`] });
      toast({
        title: "Vote Submitted",
        description: "Your prediction has been recorded!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Vote Failed", 
        description: error.message || "Failed to submit vote",
        variant: "destructive"
      });
    }
  });

  const handleVote = (direction: 'up' | 'down') => {
    voteMutation.mutate(direction);
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-4 bg-muted rounded mb-4"></div>
            <div className="h-8 bg-muted rounded mb-4"></div>
            <div className="flex space-x-2">
              <div className="h-10 bg-muted rounded flex-1"></div>
              <div className="h-10 bg-muted rounded flex-1"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const upPercentage = voteData?.upPercentage || 68;
  const totalVotes = voteData?.total || 2847;

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <i className="fas fa-users text-primary mr-2"></i>
          Crowd Prediction
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="text-3xl font-bold text-success" data-testid="text-crowd-percentage">
            {upPercentage}%
          </div>
          <div className="text-sm text-muted-foreground">
            Predict market UP tomorrow
          </div>
        </div>

        {!hasVoted ? (
          <div className="flex space-x-2">
            <Button 
              className="flex-1 bg-success hover:bg-success/80 text-success-foreground"
              onClick={() => handleVote('up')}
              disabled={voteMutation.isPending}
              data-testid="button-vote-up"
            >
              <i className="fas fa-arrow-up mr-1"></i>UP
            </Button>
            <Button 
              className="flex-1 bg-destructive hover:bg-destructive/80 text-destructive-foreground"
              onClick={() => handleVote('down')}
              disabled={voteMutation.isPending}
              data-testid="button-vote-down"
            >
              <i className="fas fa-arrow-down mr-1"></i>DOWN
            </Button>
          </div>
        ) : (
          <div className="text-center text-success">
            <i className="fas fa-check-circle mr-2"></i>
            Vote submitted! Thank you.
          </div>
        )}

        <div className="text-xs text-muted-foreground text-center" data-testid="text-vote-count">
          {totalVotes.toLocaleString()} votes cast today
        </div>
      </CardContent>
    </Card>
  );
}
