import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface PanicButtonProps {
  userId: string;
}

export default function PanicButton({ userId }: PanicButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const panicMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', `/api/panic/${userId}`, {});
    },
    onSuccess: (data: any) => {
      toast({
        title: "PANIC MODE ACTIVATED",
        description: data.message,
        variant: "destructive"
      });
      setIsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Panic Mode Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handlePanic = () => {
    panicMutation.mutate();
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogTrigger asChild>
        <Button 
          variant="destructive" 
          className="font-medium"
          data-testid="button-panic"
        >
          <i className="fas fa-exclamation-triangle mr-2"></i>PANIC
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-destructive flex items-center">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            PANIC MODE ACTIVATION
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-2">
            <p>This will immediately:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Halt ALL active trades</li>
              <li>Convert 50% of portfolio to Gold ETF</li>
              <li>Activate risk management protocols</li>
              <li>Send immediate notifications</li>
            </ul>
            <p className="text-destructive font-medium mt-4">
              This action cannot be undone. Are you sure you want to proceed?
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel data-testid="button-panic-cancel">Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={handlePanic}
            disabled={panicMutation.isPending}
            className="bg-destructive hover:bg-destructive/80"
            data-testid="button-panic-confirm"
          >
            {panicMutation.isPending ? 'Activating...' : 'ACTIVATE PANIC MODE'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
