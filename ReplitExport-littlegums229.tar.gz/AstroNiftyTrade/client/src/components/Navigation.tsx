import { Button } from "@/components/ui/button";

export default function Navigation() {
  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-primary-foreground text-sm"></i>
              </div>
              <span className="text-xl font-bold text-primary">NiftyAI</span>
              <span className="px-2 py-1 text-xs bg-accent/20 text-accent rounded-full">BETA</span>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#dashboard" className="text-primary font-medium" data-testid="link-dashboard">Dashboard</a>
              <a href="#portfolio" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-portfolio">Portfolio</a>
              <a href="#predictions" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-predictions">AI Predictions</a>
              <a href="#community" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-community">Community</a>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-muted rounded-full"></div>
              <span className="text-sm font-medium" data-testid="text-username">Raj Patel</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
