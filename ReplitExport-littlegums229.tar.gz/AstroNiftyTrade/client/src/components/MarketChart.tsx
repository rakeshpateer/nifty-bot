import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface MarketData {
  symbol: string;
  price: string;
  change: string;
}

interface MarketChartProps {
  marketData?: MarketData[];
}

export default function MarketChart({ marketData }: MarketChartProps) {
  const [activeIndex, setActiveIndex] = useState('Nifty 50');

  const mockChartBars = Array.from({ length: 20 }, (_, i) => {
    const height = Math.random() * 80 + 20; // 20% to 100% height
    const isPositive = Math.random() > 0.4;
    return {
      height: `${height}%`,
      color: isPositive ? 'bg-success' : 'bg-destructive'
    };
  });

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Market Overview</CardTitle>
          <div className="flex space-x-2">
            {['Nifty 50', 'Bank Nifty', 'Sensex'].map((index) => (
              <Button 
                key={index}
                variant={activeIndex === index ? 'default' : 'secondary'}
                size="sm"
                onClick={() => setActiveIndex(index)}
                data-testid={`button-${index.toLowerCase().replace(' ', '-')}`}
              >
                {index}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-container h-80 rounded-lg p-4">
          <div className="flex items-end justify-between h-full space-x-1" data-testid="chart-bars">
            {mockChartBars.map((bar, index) => (
              <div 
                key={index}
                className={`w-2 ${bar.color} rounded-t-sm transition-all duration-300`}
                style={{ height: bar.height }}
              />
            ))}
          </div>
        </div>
        
        {/* AI Predictions Panel */}
        <div className="mt-6">
          <h4 className="text-lg font-bold mb-4 flex items-center">
            <i className="fas fa-crystal-ball text-accent mr-2"></i>
            AI Predictions & Black Swan Analysis
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-secondary/50">
              <CardContent className="p-4">
                <h5 className="font-medium text-success mb-2">Bullish Signals</h5>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• RSI oversold in IT sector</li>
                  <li>• Venus-Jupiter alignment favorable</li>
                  <li>• Crowd sentiment: 73% bullish</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="bg-secondary/50">
              <CardContent className="p-4">
                <h5 className="font-medium text-destructive mb-2">Risk Factors</h5>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Black swan probability: 12%</li>
                  <li>• Weather mood index: neutral</li>
                  <li>• Meme sentiment declining</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
