import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Trade {
  symbol: string;
  type: string;
  price: string;
  aiStory?: string;
  createdAt: Date;
}

interface AIStorytellingProps {
  trades?: Trade[];
}

export default function AIStorytelling({ trades = [] }: AIStorytellingProps) {
  // Sample stories when no trades available
  const sampleStories = [
    {
      action: "BOUGHT INFY @ ₹1,420",
      time: "2 hours ago",
      type: "buy",
      story: "Mercury entering Gemini traditionally signals good fortune for tech stocks. Combined with RSI showing oversold conditions and positive meme sentiment around #InfyToTheMoon, the AI detected a 78% probability of upward movement. The crowd was 82% bullish, reinforcing our conviction.",
      lesson: "Astrological patterns + technical analysis can identify low-risk entries"
    },
    {
      action: "SOLD TCS @ ₹3,890", 
      time: "1 day ago",
      type: "sell",
      story: "Black swan probability spiked to 23% due to unusual options activity. Weather mood index showed heavy rains in Bangalore (TCS headquarters), historically correlating with -2.1% moves. Despite positive fundamentals, risk management triggered an exit.",
      lesson: "Sometimes preservation of capital trumps potential gains"
    }
  ];

  const displayTrades = trades.length > 0 ? trades.slice(0, 2) : sampleStories;

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-book-open text-primary mr-2"></i>
          AI Trade Storytelling
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {displayTrades.map((trade, index) => {
          const isRealTrade = 'createdAt' in trade;
          const actionText = isRealTrade 
            ? `${trade.type.toUpperCase()} ${trade.symbol} @ ₹${trade.price}`
            : (trade as any).action;
          const timeText = isRealTrade 
            ? new Date(trade.createdAt).toLocaleString()
            : (trade as any).time;
          const storyText = isRealTrade 
            ? trade.aiStory || "Trade executed based on AI analysis."
            : (trade as any).story;
          const lessonText = isRealTrade 
            ? "AI-driven decision making improves over time with more data."
            : (trade as any).lesson;
          const tradeType = isRealTrade 
            ? trade.type 
            : (trade as any).type;

          return (
            <Card key={index} className="bg-secondary/50" data-testid={`card-trade-story-${index}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className={`font-medium ${tradeType === 'buy' ? 'text-success' : 'text-destructive'}`}>
                    {actionText}
                  </span>
                  <span className="text-xs text-muted-foreground">{timeText}</span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {storyText}
                </p>
                <div className="text-xs text-accent">
                  Lesson: {lessonText}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </CardContent>
    </Card>
  );
}
