import { Card, CardContent } from "@/components/ui/card";

interface PortfolioData {
  user?: {
    portfolioValue: string;
    charityFund: string;
  };
  trades?: Array<{ status: string }>;
}

interface PortfolioOverviewProps {
  data: PortfolioData;
}

export default function PortfolioOverview({ data }: PortfolioOverviewProps) {
  const portfolioValue = data?.user?.portfolioValue || "0";
  const charityFund = data?.user?.charityFund || "0";
  const activeTrades = data?.trades?.filter(t => t.status === 'active').length || 0;
  const profitableTrades = Math.floor(activeTrades * 0.64); // ~64% profitable

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground text-sm">Portfolio Value</span>
            <i className="fas fa-wallet text-primary"></i>
          </div>
          <div className="text-2xl font-bold text-success" data-testid="text-portfolio-value">
            ₹{parseFloat(portfolioValue).toLocaleString('en-IN')}
          </div>
          <div className="text-sm text-success flex items-center">
            <i className="fas fa-arrow-up mr-1"></i>+2.3% today
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground text-sm">AI Confidence</span>
            <i className="fas fa-brain text-accent"></i>
          </div>
          <div className="text-2xl font-bold text-accent" data-testid="text-ai-confidence">
            87%
          </div>
          <div className="text-sm text-muted-foreground">High confidence</div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground text-sm">Active Trades</span>
            <i className="fas fa-exchange-alt text-primary"></i>
          </div>
          <div className="text-2xl font-bold" data-testid="text-active-trades">
            {activeTrades}
          </div>
          <div className="text-sm text-success">{profitableTrades} profitable</div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground text-sm">Charity Fund</span>
            <i className="fas fa-heart text-destructive"></i>
          </div>
          <div className="text-2xl font-bold text-destructive" data-testid="text-charity-fund">
            ₹{parseFloat(charityFund).toLocaleString('en-IN')}
          </div>
          <div className="text-sm text-muted-foreground">Auto-donated</div>
        </CardContent>
      </Card>
    </div>
  );
}
