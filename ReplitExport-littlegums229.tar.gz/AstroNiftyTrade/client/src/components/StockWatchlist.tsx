import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface MarketData {
  symbol: string;
  price: string;
  change: string;
  volume: string;
}

interface StockWatchlistProps {
  marketData?: MarketData[];
}

export default function StockWatchlist({ marketData = [] }: StockWatchlistProps) {
  const getMemeScore = () => (Math.random() * 10).toFixed(1);
  const getAISignal = (change: string) => {
    const changeNum = parseFloat(change);
    if (changeNum > 1) return { label: 'BUY', color: 'bg-success/20 text-success' };
    if (changeNum < -1) return { label: 'SELL', color: 'bg-destructive/20 text-destructive' };
    return { label: 'HOLD', color: 'bg-muted text-muted-foreground' };
  };

  const getMemeIcon = (score: number) => {
    if (score > 7) return 'fas fa-rocket text-accent';
    if (score > 5) return 'fas fa-fire text-accent';
    return 'fas fa-meh text-muted-foreground';
  };

  const getCompanyName = (symbol: string) => {
    const names: Record<string, string> = {
      'RELIANCE': 'Reliance Industries',
      'HDFCBANK': 'HDFC Bank',
      'INFY': 'Infosys',
      'ICICIBANK': 'ICICI Bank',
      'TCS': 'Tata Consultancy Services',
      'BHARTIARTL': 'Bharti Airtel',
      'ITC': 'ITC Limited',
      'SBIN': 'State Bank of India'
    };
    return names[symbol] || symbol;
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle>Nifty 50 & Bank Nifty Watchlist</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-border">
              <tr className="text-muted-foreground">
                <th className="text-left py-3">Symbol</th>
                <th className="text-right py-3">Price</th>
                <th className="text-right py-3">Change</th>
                <th className="text-right py-3">Volume</th>
                <th className="text-center py-3">AI Signal</th>
                <th className="text-center py-3">Meme Score</th>
                <th className="text-center py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {marketData.slice(0, 8).map((stock, index) => {
                const memeScore = parseFloat(getMemeScore());
                const aiSignal = getAISignal(stock.change);
                const isPositive = parseFloat(stock.change) > 0;
                
                return (
                  <tr key={index} data-testid={`row-stock-${stock.symbol}`}>
                    <td className="py-3">
                      <div className="font-medium">{stock.symbol}</div>
                      <div className="text-muted-foreground text-xs">
                        {getCompanyName(stock.symbol)}
                      </div>
                    </td>
                    <td className="text-right py-3" data-testid={`text-price-${stock.symbol}`}>
                      ₹{parseFloat(stock.price).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className={`text-right py-3 ${isPositive ? 'text-success' : 'text-destructive'}`}>
                      {isPositive ? '+' : ''}{stock.change}%
                    </td>
                    <td className="text-right py-3 text-muted-foreground">{stock.volume}</td>
                    <td className="text-center py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${aiSignal.color}`}>
                        {aiSignal.label}
                      </span>
                    </td>
                    <td className="text-center py-3">
                      <div className="flex items-center justify-center">
                        <i className={getMemeIcon(memeScore) + " mr-1"}></i>
                        <span className="text-xs">{memeScore}</span>
                      </div>
                    </td>
                    <td className="text-center py-3">
                      <Button 
                        size="sm" 
                        className="text-xs"
                        data-testid={`button-trade-${stock.symbol}`}
                      >
                        Trade
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
