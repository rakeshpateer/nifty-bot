import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MemesentimentAnalyzer() {
  const { data: memeData, isLoading } = useQuery({
    queryKey: ['/api/meme-analysis'],
  });

  // Sample data for when API is not available
  const sampleData = {
    trending: [
      { hashtag: '#RelianceToMars', change: '+234%', status: 'rising' as const },
      { hashtag: '#HDFCBankRun', change: '-89%', status: 'falling' as const }
    ],
    scores: [
      { symbol: 'RELIANCE', score: 9.2 },
      { symbol: 'TCS', score: 6.8 },
      { symbol: 'INFY', score: 7.5 }
    ],
    aiInsight: "Detected increased retail FOMO in IT sector based on meme velocity. Recommend caution as viral sentiment often precedes corrections."
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-20 bg-muted rounded"></div>
            <div className="h-16 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const displayData = memeData || sampleData;

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-laugh-squint text-accent mr-2"></i>
          Meme Sentiment Analyzer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Trending Memes */}
          <div className="space-y-4">
            <h4 className="font-medium text-primary">Trending Stock Memes</h4>
            <div className="space-y-3">
              {displayData.trending.map((meme: any, index: number) => (
                <Card key={index} className="bg-secondary/50" data-testid={`card-meme-${index}`}>
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{meme.hashtag}</span>
                      <span className={`text-xs ${meme.status === 'rising' ? 'text-success' : 'text-destructive'}`}>
                        {meme.change}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {meme.status === 'rising' ? 'Viral across platforms' : 'Declining mentions'}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Virality Scores */}
          <div className="space-y-4">
            <h4 className="font-medium text-primary">Virality Score Impact</h4>
            <div className="space-y-3">
              {displayData.scores.map((stock: any, index: number) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm">{stock.symbol}</span>
                  <div className="flex items-center">
                    <div className="w-16 h-2 bg-secondary rounded-full mr-2">
                      <div 
                        className="h-2 bg-success rounded-full" 
                        style={{ width: `${(stock.score / 10) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-success" data-testid={`text-meme-score-${stock.symbol}`}>
                      {stock.score}/10
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Analysis */}
          <div className="space-y-4">
            <h4 className="font-medium text-primary">AI Sentiment Analysis</h4>
            <div className="text-sm text-muted-foreground" data-testid="text-ai-meme-insight">
              "{displayData.aiInsight}"
            </div>
            <div className="text-xs text-accent">Confidence: 76%</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
