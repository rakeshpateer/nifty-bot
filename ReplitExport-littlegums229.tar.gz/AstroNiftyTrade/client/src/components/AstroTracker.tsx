import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AstroTracker() {
  const { data: astroData, isLoading } = useQuery({
    queryKey: ['/api/astrology/current'],
    queryFn: async () => {
      // Since we don't have a real astrology API, return sample data
      return {
        alignment: "Venus conjunction with Jupiter in 7th house - Traditionally bullish for banking sector",
        accuracy: 64,
        blackSwan: {
          threatLevel: "MODERATE",
          signals: 847,
          indicators: [
            { name: "Options Skew", status: "Normal", color: "success" },
            { name: "VIX", status: "Elevated", color: "accent" }
          ]
        }
      };
    }
  });

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-20 bg-muted rounded"></div>
            <div className="h-16 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const data = astroData || {
    alignment: "Venus conjunction with Jupiter - favorable alignment",
    accuracy: 64,
    blackSwan: {
      threatLevel: "MODERATE",
      signals: 847,
      indicators: [
        { name: "Options Skew", status: "Normal", color: "success" },
        { name: "VIX", status: "Elevated", color: "accent" }
      ]
    }
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-meteor text-accent mr-2"></i>
          Astro-Financial Tracker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Planetary Alignment */}
        <Card className="bg-gradient-to-r from-accent/20 to-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Current Planetary Alignment</span>
              <i className="fas fa-star text-accent"></i>
            </div>
            <div className="text-sm text-muted-foreground mb-2" data-testid="text-astrology-alignment">
              {data.alignment}
            </div>
            <div className="text-xs text-success">
              Historical accuracy: {data.accuracy}% over 50 trades
            </div>
          </CardContent>
        </Card>

        {/* Black Swan Alert System */}
        <Card className="bg-gradient-to-r from-destructive/20 to-accent/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Black Swan Alert System</span>
              <div className="w-3 h-3 bg-accent rounded-full animate-pulse"></div>
            </div>
            <div className="text-sm text-muted-foreground mb-2" data-testid="text-black-swan-status">
              Monitoring {data.blackSwan.signals} unusual market signals. Current threat level: {data.blackSwan.threatLevel}
            </div>
            <div className="flex space-x-2 text-xs">
              {data.blackSwan.indicators.map((indicator: any, index: number) => (
                <span 
                  key={index}
                  className={`px-2 py-1 rounded bg-${indicator.color}/20 text-${indicator.color}`}
                  data-testid={`indicator-${indicator.name.toLowerCase().replace(' ', '-')}`}
                >
                  {indicator.name}: {indicator.status}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}
