import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function WeatherMoodIndex() {
  const { data: weatherData, isLoading } = useQuery({
    queryKey: ['/api/weather-mood'],
  });

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-16 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sample data when API is not available
  const data = weatherData || {
    mumbai: {
      weather: 'Sunny',
      marketImpact: 0.8,
      icon: 'sun'
    },
    bangalore: {
      weather: 'Light Rain',
      marketImpact: -0.3,
      icon: 'cloud-rain'
    },
    correlation: 0.67
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <i className="fas fa-cloud-sun text-accent mr-2"></i>
          Weather Mood Index
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Mumbai</span>
          <div className="flex items-center">
            <i className={`fas fa-${data.mumbai.icon} ${data.mumbai.marketImpact > 0 ? 'text-accent' : 'text-muted-foreground'} mr-2`}></i>
            <span className={`font-medium ${data.mumbai.marketImpact > 0 ? 'text-success' : 'text-destructive'}`} data-testid="text-mumbai-impact">
              {data.mumbai.marketImpact > 0 ? '+' : ''}{(data.mumbai.marketImpact * 100).toFixed(1)}%
            </span>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Bangalore</span>
          <div className="flex items-center">
            <i className={`fas fa-${data.bangalore.icon} ${data.bangalore.marketImpact > 0 ? 'text-accent' : 'text-muted-foreground'} mr-2`}></i>
            <span className={`font-medium ${data.bangalore.marketImpact > 0 ? 'text-success' : 'text-destructive'}`} data-testid="text-bangalore-impact">
              {data.bangalore.marketImpact > 0 ? '+' : ''}{(data.bangalore.marketImpact * 100).toFixed(1)}%
            </span>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground" data-testid="text-weather-correlation">
          Historical correlation: {(data.correlation * 100).toFixed(0)}%
        </div>
      </CardContent>
    </Card>
  );
}
