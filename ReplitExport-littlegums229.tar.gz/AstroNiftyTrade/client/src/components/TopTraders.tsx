import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function TopTraders() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: topTraders, isLoading } = useQuery({
    queryKey: ['/api/top-traders'],
  });

  const cloneMutation = useMutation({
    mutationFn: async (traderId: string) => {
      return apiRequest('POST', `/api/clone-trader/${traderId}`, {
        userId: 'user-1' // In real app, get from auth
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Portfolio Cloned",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Clone Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleClone = (traderId: string) => {
    cloneMutation.mutate(traderId);
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-16 bg-muted rounded"></div>
            <div className="h-16 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <i className="fas fa-clone text-accent mr-2"></i>
          Clone Top Traders
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {(topTraders || []).slice(0, 3).map((trader: any, index: number) => (
          <Card key={trader.id || index} className="bg-secondary/50" data-testid={`card-trader-${index}`}>
            <CardContent className="flex items-center justify-between p-3">
              <div>
                <div className="font-medium" data-testid={`text-trader-name-${index}`}>
                  @{trader.username}
                </div>
                <div className="text-sm text-success" data-testid={`text-trader-return-${index}`}>
                  +{trader.monthlyReturn}% this month
                </div>
              </div>
              <Button 
                size="sm"
                onClick={() => handleClone(trader.id)}
                disabled={cloneMutation.isPending}
                data-testid={`button-clone-${index}`}
              >
                Clone
              </Button>
            </CardContent>
          </Card>
        ))}
      </CardContent>
    </Card>
  );
}
