import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  portfolioValue: decimal("portfolio_value", { precision: 15, scale: 2 }).default("100000"),
  charityFund: decimal("charity_fund", { precision: 10, scale: 2 }).default("0"),
  ethicalMode: boolean("ethical_mode").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const portfolios = pgTable("portfolios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  symbol: text("symbol").notNull(),
  quantity: integer("quantity").notNull(),
  averagePrice: decimal("average_price", { precision: 10, scale: 2 }).notNull(),
  currentPrice: decimal("current_price", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  symbol: text("symbol").notNull(),
  type: text("type").notNull(), // 'buy' | 'sell'
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  status: text("status").default("active"), // 'active' | 'completed' | 'cancelled'
  aiStory: text("ai_story"),
  aiConfidence: integer("ai_confidence"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(), // 'up' | 'down'
  confidence: integer("confidence").notNull(),
  blackSwanProbability: decimal("black_swan_probability", { precision: 5, scale: 2 }),
  astrologyFactor: text("astrology_factor"),
  weatherMoodIndex: decimal("weather_mood_index", { precision: 3, scale: 2 }),
  memeScore: decimal("meme_score", { precision: 3, scale: 1 }),
  crowdSentiment: decimal("crowd_sentiment", { precision: 3, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const crowdVotes = pgTable("crowd_votes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(), // 'up' | 'down'
  date: text("date").notNull(), // YYYY-MM-DD format
  createdAt: timestamp("created_at").defaultNow(),
});

export const topTraders = pgTable("top_traders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  username: text("username").notNull(),
  monthlyReturn: decimal("monthly_return", { precision: 5, scale: 2 }).notNull(),
  followersCount: integer("followers_count").default(0),
  consentToClone: boolean("consent_to_clone").default(false),
  portfolioData: jsonb("portfolio_data"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  change: decimal("change", { precision: 5, scale: 2 }).notNull(),
  volume: text("volume").notNull(),
  marketCap: text("market_cap"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const memeAnalysis = pgTable("meme_analysis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  hashtag: text("hashtag").notNull(),
  viralityScore: decimal("virality_score", { precision: 3, scale: 1 }).notNull(),
  sentiment: text("sentiment").notNull(), // 'positive' | 'negative' | 'neutral'
  platforms: text("platforms").array(),
  mentions: integer("mentions").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertPortfolioSchema = createInsertSchema(portfolios).omit({ id: true, createdAt: true });
export const insertTradeSchema = createInsertSchema(trades).omit({ id: true, createdAt: true });
export const insertPredictionSchema = createInsertSchema(predictions).omit({ id: true, createdAt: true });
export const insertCrowdVoteSchema = createInsertSchema(crowdVotes).omit({ id: true, createdAt: true });
export const insertTopTraderSchema = createInsertSchema(topTraders).omit({ id: true, updatedAt: true });
export const insertMarketDataSchema = createInsertSchema(marketData).omit({ id: true, updatedAt: true });
export const insertMemeAnalysisSchema = createInsertSchema(memeAnalysis).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type CrowdVote = typeof crowdVotes.$inferSelect;
export type InsertCrowdVote = z.infer<typeof insertCrowdVoteSchema>;
export type TopTrader = typeof topTraders.$inferSelect;
export type InsertTopTrader = z.infer<typeof insertTopTraderSchema>;
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;
export type MemeAnalysis = typeof memeAnalysis.$inferSelect;
export type InsertMemeAnalysis = z.infer<typeof insertMemeAnalysisSchema>;
