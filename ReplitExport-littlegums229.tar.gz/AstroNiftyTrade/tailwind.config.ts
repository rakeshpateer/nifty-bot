import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        primary: {
          DEFAULT: "var(--primary)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          foreground: "var(--secondary-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          foreground: "var(--accent-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        success: {
          DEFAULT: "var(--success)",
          foreground: "var(--success-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        serif: ["var(--font-serif)"],
        mono: ["var(--font-mono)"],
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "trading-pulse": {
          "0%, 100%": {
            opacity: "1",
            transform: "scale(1)",
          },
          "50%": {
            opacity: "0.7",
            transform: "scale(1.05)",
          },
        },
        "mystical-pulse": {
          "0%, 100%": {
            boxShadow: "0 0 20px var(--accent), 0 0 40px var(--accent)",
          },
          "50%": {
            boxShadow: "0 0 30px var(--accent), 0 0 60px var(--accent)",
          },
        },
        "panic-pulse": {
          "0%, 100%": {
            transform: "scale(1)",
            boxShadow: "0 0 20px rgba(220, 38, 127, 0.3)",
          },
          "50%": {
            transform: "scale(1.05)",
            boxShadow: "0 0 30px rgba(220, 38, 127, 0.5)",
          },
        },
        "shimmer": {
          "0%": {
            backgroundPosition: "-200% 0",
          },
          "100%": {
            backgroundPosition: "200% 0",
          },
        },
        "flash": {
          "0%, 100%": {
            backgroundColor: "transparent",
          },
          "50%": {
            backgroundColor: "var(--primary)",
            opacity: "0.2",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "trading-pulse": "trading-pulse 2s infinite",
        "mystical-pulse": "mystical-pulse 3s infinite",
        "panic-pulse": "panic-pulse 1s infinite",
        "shimmer": "shimmer 1.5s infinite",
        "flash": "flash 0.5s ease-in-out",
      },
      backgroundImage: {
        "nifty-gradient": "linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%)",
        "success-gradient": "linear-gradient(135deg, var(--success) 0%, var(--primary) 100%)",
        "danger-gradient": "linear-gradient(135deg, var(--destructive) 0%, var(--accent) 100%)",
        "chart-gradient": "linear-gradient(135deg, rgba(0, 210, 255, 0.1) 0%, rgba(255, 215, 0, 0.1) 100%)",
      },
      boxShadow: {
        "nifty": "0 0 20px var(--primary), 0 0 40px var(--primary)",
        "panic": "0 0 20px rgba(220, 38, 127, 0.3)",
        "success": "0 0 15px var(--success)",
        "accent": "0 0 15px var(--accent)",
      },
      spacing: {
        "safe-top": "env(safe-area-inset-top)",
        "safe-bottom": "env(safe-area-inset-bottom)",
        "safe-left": "env(safe-area-inset-left)",
        "safe-right": "env(safe-area-inset-right)",
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"), 
    require("@tailwindcss/typography"),
  ],
} satisfies Config;
