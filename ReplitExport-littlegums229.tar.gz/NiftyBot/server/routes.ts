import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { storage } from "./storage";
import { stockService } from "./services/stockService";
import { aiService } from "./services/aiService";
import { technicalIndicatorService } from "./services/technicalIndicators";
import { insertWatchlistSchema, insertTradeSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Initialize stocks on server start
  await stockService.initializeStocks();

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Market data routes
  app.get('/api/market/indices', async (req, res) => {
    try {
      const indices = await stockService.getMarketIndices();
      res.json(indices);
    } catch (error) {
      console.error("Error fetching market indices:", error);
      res.status(500).json({ message: "Failed to fetch market indices" });
    }
  });

  app.get('/api/stocks', async (req, res) => {
    try {
      const stocks = await storage.getAllStocks();
      
      // Get latest prices for each stock
      const stocksWithPrices = await Promise.all(
        stocks.map(async (stock) => {
          const latestPrice = await storage.getLatestPrice(stock.id);
          return { ...stock, latestPrice };
        })
      );
      
      res.json(stocksWithPrices);
    } catch (error) {
      console.error("Error fetching stocks:", error);
      res.status(500).json({ message: "Failed to fetch stocks" });
    }
  });

  app.get('/api/stocks/:symbol/price', async (req, res) => {
    try {
      const { symbol } = req.params;
      const quote = await stockService.fetchLivePrice(symbol + '.NS');
      
      if (!quote) {
        return res.status(404).json({ message: "Stock not found" });
      }
      
      res.json(quote);
    } catch (error) {
      console.error(`Error fetching price for ${req.params.symbol}:`, error);
      res.status(500).json({ message: "Failed to fetch stock price" });
    }
  });

  app.get('/api/stocks/:symbol/historical', async (req, res) => {
    try {
      const { symbol } = req.params;
      const { period = '1mo' } = req.query;
      
      const historicalData = await stockService.getHistoricalData(symbol + '.NS', period as string);
      res.json(historicalData);
    } catch (error) {
      console.error(`Error fetching historical data for ${req.params.symbol}:`, error);
      res.status(500).json({ message: "Failed to fetch historical data" });
    }
  });

  app.get('/api/stocks/:symbol/indicators', async (req, res) => {
    try {
      const { symbol } = req.params;
      const historicalData = await stockService.getHistoricalData(symbol + '.NS', '3mo');
      
      if (historicalData.length < 50) {
        return res.status(400).json({ message: "Insufficient data for indicator calculation" });
      }
      
      const prices = historicalData.map(d => d.close);
      const volumes = historicalData.map(d => d.volume);
      const highs = historicalData.map(d => d.high);
      const lows = historicalData.map(d => d.low);
      
      const indicators = technicalIndicatorService.calculateIndicators(prices, volumes);
      const supertrend = technicalIndicatorService.calculateSupertrendSignal(prices, highs, lows);
      const signal = technicalIndicatorService.generateTradingSignal(indicators, prices[prices.length - 1]);
      
      res.json({ indicators, supertrend, signal });
    } catch (error) {
      console.error(`Error calculating indicators for ${req.params.symbol}:`, error);
      res.status(500).json({ message: "Failed to calculate technical indicators" });
    }
  });

  // Portfolio routes
  app.get('/api/portfolio', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let portfolio = await storage.getUserPortfolio(userId);
      
      if (!portfolio) {
        portfolio = await storage.createPortfolio({
          userId,
          name: 'Default Portfolio',
        });
      }
      
      res.json(portfolio);
    } catch (error) {
      console.error("Error fetching portfolio:", error);
      res.status(500).json({ message: "Failed to fetch portfolio" });
    }
  });

  // Trading routes
  app.get('/api/trades', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit = 20 } = req.query;
      
      const trades = await storage.getUserTrades(userId, parseInt(limit as string));
      res.json(trades);
    } catch (error) {
      console.error("Error fetching trades:", error);
      res.status(500).json({ message: "Failed to fetch trades" });
    }
  });

  app.post('/api/trades', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tradeData = insertTradeSchema.parse({ ...req.body, userId });
      
      // Get or create portfolio
      let portfolio = await storage.getUserPortfolio(userId);
      if (!portfolio) {
        portfolio = await storage.createPortfolio({ userId });
      }
      
      tradeData.portfolioId = portfolio.id;
      
      const trade = await storage.createTrade(tradeData);
      
      // Update portfolio values (simplified calculation)
      const tradeAmount = Number(trade.amount);
      const currentTotal = Number(portfolio.totalValue);
      const currentInvested = Number(portfolio.totalInvested);
      
      const newTotalInvested = trade.type === 'BUY' ? 
        currentInvested + tradeAmount : 
        currentInvested - tradeAmount;
      
      await storage.updatePortfolio(portfolio.id, {
        totalInvested: newTotalInvested.toString(),
        totalValue: (currentTotal + (trade.type === 'BUY' ? tradeAmount : -tradeAmount)).toString(),
      });
      
      res.json(trade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid trade data", errors: error.errors });
      }
      console.error("Error creating trade:", error);
      res.status(500).json({ message: "Failed to create trade" });
    }
  });

  // Watchlist routes
  app.get('/api/watchlist', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const watchlist = await storage.getUserWatchlist(userId);
      res.json(watchlist);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      res.status(500).json({ message: "Failed to fetch watchlist" });
    }
  });

  app.post('/api/watchlist', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const watchlistData = insertWatchlistSchema.parse({ ...req.body, userId });
      
      const watchlistItem = await storage.addToWatchlist(watchlistData);
      res.json(watchlistItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid watchlist data", errors: error.errors });
      }
      console.error("Error adding to watchlist:", error);
      res.status(500).json({ message: "Failed to add to watchlist" });
    }
  });

  app.delete('/api/watchlist/:stockId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { stockId } = req.params;
      
      await storage.removeFromWatchlist(userId, stockId);
      res.json({ message: "Removed from watchlist" });
    } catch (error) {
      console.error("Error removing from watchlist:", error);
      res.status(500).json({ message: "Failed to remove from watchlist" });
    }
  });

  // AI and analysis routes
  app.get('/api/signals', async (req, res) => {
    try {
      const { limit = 10 } = req.query;
      const signals = await storage.getLatestSignals(parseInt(limit as string));
      res.json(signals);
    } catch (error) {
      console.error("Error fetching trading signals:", error);
      res.status(500).json({ message: "Failed to fetch trading signals" });
    }
  });

  app.get('/api/sentiment', async (req, res) => {
    try {
      const sentiment = await storage.getLatestSentiment();
      res.json(sentiment);
    } catch (error) {
      console.error("Error fetching market sentiment:", error);
      res.status(500).json({ message: "Failed to fetch market sentiment" });
    }
  });

  app.get('/api/risk/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.params.userId;
      
      // Verify user can access this data
      if (req.user.claims.sub !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const riskMetrics = await aiService.calculatePortfolioRisk(userId);
      res.json(riskMetrics);
    } catch (error) {
      console.error("Error calculating risk metrics:", error);
      res.status(500).json({ message: "Failed to calculate risk metrics" });
    }
  });

  // Background tasks - these would typically run as scheduled jobs
  app.post('/api/admin/update-prices', async (req, res) => {
    try {
      await stockService.updateAllPrices();
      res.json({ message: "Price update initiated" });
    } catch (error) {
      console.error("Error updating prices:", error);
      res.status(500).json({ message: "Failed to update prices" });
    }
  });

  app.post('/api/admin/analyze-sentiment', async (req, res) => {
    try {
      await aiService.analyzeMarketSentiment();
      res.json({ message: "Sentiment analysis completed" });
    } catch (error) {
      console.error("Error analyzing sentiment:", error);
      res.status(500).json({ message: "Failed to analyze sentiment" });
    }
  });

  app.post('/api/admin/generate-signals', async (req, res) => {
    try {
      await aiService.generateTradingSignals();
      res.json({ message: "Signal generation completed" });
    } catch (error) {
      console.error("Error generating signals:", error);
      res.status(500).json({ message: "Failed to generate signals" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
