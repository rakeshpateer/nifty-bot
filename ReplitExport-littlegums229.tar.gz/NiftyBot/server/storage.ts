import {
  users,
  stocks,
  stockPrices,
  portfolios,
  trades,
  watchlists,
  tradingSignals,
  marketSentiment,
  type User,
  type UpsertUser,
  type Stock,
  type InsertStock,
  type StockPrice,
  type InsertStockPrice,
  type Portfolio,
  type InsertPortfolio,
  type Trade,
  type InsertTrade,
  type Watchlist,
  type InsertWatchlist,
  type TradingSignal,
  type InsertTradingSignal,
  type MarketSentiment,
  type InsertMarketSentiment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Stock operations
  getStock(symbol: string): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;
  getAllStocks(): Promise<Stock[]>;
  
  // Stock price operations
  getLatestPrice(stockId: string): Promise<StockPrice | undefined>;
  createStockPrice(price: InsertStockPrice): Promise<StockPrice>;
  getHistoricalPrices(stockId: string, limit: number): Promise<StockPrice[]>;
  
  // Portfolio operations
  getUserPortfolio(userId: string): Promise<Portfolio | undefined>;
  createPortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;
  updatePortfolio(id: string, updates: Partial<Portfolio>): Promise<Portfolio>;
  
  // Trade operations
  createTrade(trade: InsertTrade): Promise<Trade>;
  getUserTrades(userId: string, limit: number): Promise<Trade[]>;
  
  // Watchlist operations
  getUserWatchlist(userId: string): Promise<(Watchlist & { stock: Stock; latestPrice?: StockPrice })[]>;
  addToWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: string, stockId: string): Promise<void>;
  
  // Trading signals
  getLatestSignals(limit: number): Promise<(TradingSignal & { stock: Stock })[]>;
  createTradingSignal(signal: InsertTradingSignal): Promise<TradingSignal>;
  
  // Market sentiment
  getLatestSentiment(): Promise<MarketSentiment | undefined>;
  createMarketSentiment(sentiment: InsertMarketSentiment): Promise<MarketSentiment>;
}

export class DatabaseStorage implements IStorage {
  // User operations - mandatory for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Stock operations
  async getStock(symbol: string): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.symbol, symbol));
    return stock;
  }

  async createStock(stock: InsertStock): Promise<Stock> {
    const [newStock] = await db.insert(stocks).values(stock).returning();
    return newStock;
  }

  async getAllStocks(): Promise<Stock[]> {
    return await db.select().from(stocks).where(eq(stocks.isActive, true));
  }

  // Stock price operations
  async getLatestPrice(stockId: string): Promise<StockPrice | undefined> {
    const [price] = await db
      .select()
      .from(stockPrices)
      .where(eq(stockPrices.stockId, stockId))
      .orderBy(desc(stockPrices.timestamp))
      .limit(1);
    return price;
  }

  async createStockPrice(price: InsertStockPrice): Promise<StockPrice> {
    const [newPrice] = await db.insert(stockPrices).values(price).returning();
    return newPrice;
  }

  async getHistoricalPrices(stockId: string, limit: number): Promise<StockPrice[]> {
    return await db
      .select()
      .from(stockPrices)
      .where(eq(stockPrices.stockId, stockId))
      .orderBy(desc(stockPrices.timestamp))
      .limit(limit);
  }

  // Portfolio operations
  async getUserPortfolio(userId: string): Promise<Portfolio | undefined> {
    const [portfolio] = await db
      .select()
      .from(portfolios)
      .where(eq(portfolios.userId, userId));
    return portfolio;
  }

  async createPortfolio(portfolio: InsertPortfolio): Promise<Portfolio> {
    const [newPortfolio] = await db.insert(portfolios).values(portfolio).returning();
    return newPortfolio;
  }

  async updatePortfolio(id: string, updates: Partial<Portfolio>): Promise<Portfolio> {
    const [updatedPortfolio] = await db
      .update(portfolios)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(portfolios.id, id))
      .returning();
    return updatedPortfolio;
  }

  // Trade operations
  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [newTrade] = await db.insert(trades).values(trade).returning();
    return newTrade;
  }

  async getUserTrades(userId: string, limit: number): Promise<Trade[]> {
    return await db
      .select()
      .from(trades)
      .where(eq(trades.userId, userId))
      .orderBy(desc(trades.executedAt))
      .limit(limit);
  }

  // Watchlist operations
  async getUserWatchlist(userId: string): Promise<(Watchlist & { stock: Stock; latestPrice?: StockPrice })[]> {
    const result = await db
      .select({
        id: watchlists.id,
        userId: watchlists.userId,
        stockId: watchlists.stockId,
        addedAt: watchlists.addedAt,
        stock: stocks,
      })
      .from(watchlists)
      .innerJoin(stocks, eq(watchlists.stockId, stocks.id))
      .where(eq(watchlists.userId, userId));

    // Get latest prices for each stock
    const watchlistWithPrices = await Promise.all(
      result.map(async (item) => {
        const latestPrice = await this.getLatestPrice(item.stockId);
        return { ...item, latestPrice };
      })
    );

    return watchlistWithPrices;
  }

  async addToWatchlist(watchlist: InsertWatchlist): Promise<Watchlist> {
    const [newWatchlist] = await db.insert(watchlists).values(watchlist).returning();
    return newWatchlist;
  }

  async removeFromWatchlist(userId: string, stockId: string): Promise<void> {
    await db
      .delete(watchlists)
      .where(and(eq(watchlists.userId, userId), eq(watchlists.stockId, stockId)));
  }

  // Trading signals
  async getLatestSignals(limit: number): Promise<(TradingSignal & { stock: Stock })[]> {
    return await db
      .select({
        id: tradingSignals.id,
        stockId: tradingSignals.stockId,
        type: tradingSignals.type,
        confidence: tradingSignals.confidence,
        targetPrice: tradingSignals.targetPrice,
        stopLoss: tradingSignals.stopLoss,
        reasoning: tradingSignals.reasoning,
        indicators: tradingSignals.indicators,
        createdAt: tradingSignals.createdAt,
        expiresAt: tradingSignals.expiresAt,
        stock: stocks,
      })
      .from(tradingSignals)
      .innerJoin(stocks, eq(tradingSignals.stockId, stocks.id))
      .orderBy(desc(tradingSignals.createdAt))
      .limit(limit);
  }

  async createTradingSignal(signal: InsertTradingSignal): Promise<TradingSignal> {
    const [newSignal] = await db.insert(tradingSignals).values(signal).returning();
    return newSignal;
  }

  // Market sentiment
  async getLatestSentiment(): Promise<MarketSentiment | undefined> {
    const [sentiment] = await db
      .select()
      .from(marketSentiment)
      .orderBy(desc(marketSentiment.createdAt))
      .limit(1);
    return sentiment;
  }

  async createMarketSentiment(sentiment: InsertMarketSentiment): Promise<MarketSentiment> {
    const [newSentiment] = await db.insert(marketSentiment).values(sentiment).returning();
    return newSentiment;
  }
}

export const storage = new DatabaseStorage();
