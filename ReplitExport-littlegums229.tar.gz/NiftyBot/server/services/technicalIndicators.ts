import { RSI, MACD, SMA, EMA, BollingerBands } from 'technicalindicators';

export interface TechnicalIndicatorResult {
  rsi: number | null;
  macd: {
    MACD: number | null;
    signal: number | null;
    histogram: number | null;
  };
  sma20: number | null;
  sma50: number | null;
  ema20: number | null;
  bollingerBands: {
    upper: number | null;
    middle: number | null;
    lower: number | null;
  };
  volume: number;
}

export class TechnicalIndicatorService {
  calculateIndicators(prices: number[], volumes: number[]): TechnicalIndicatorResult {
    if (prices.length < 50) {
      return this.getEmptyResult(volumes[volumes.length - 1] || 0);
    }

    try {
      // RSI calculation
      const rsiValues = RSI.calculate({ values: prices, period: 14 });
      const currentRSI = rsiValues.length > 0 ? rsiValues[rsiValues.length - 1] : null;

      // MACD calculation
      const macdValues = MACD.calculate({
        values: prices,
        fastPeriod: 12,
        slowPeriod: 26,
        signalPeriod: 9,
        SimpleMAOscillator: false,
        SimpleMASignal: false
      });
      const currentMACD = macdValues.length > 0 ? macdValues[macdValues.length - 1] : null;

      // Moving averages
      const sma20Values = SMA.calculate({ values: prices, period: 20 });
      const sma50Values = SMA.calculate({ values: prices, period: 50 });
      const ema20Values = EMA.calculate({ values: prices, period: 20 });

      // Bollinger Bands
      const bbValues = BollingerBands.calculate({
        values: prices,
        period: 20,
        stdDev: 2
      });

      return {
        rsi: currentRSI,
        macd: {
          MACD: currentMACD?.MACD || null,
          signal: currentMACD?.signal || null,
          histogram: currentMACD?.histogram || null,
        },
        sma20: sma20Values.length > 0 ? sma20Values[sma20Values.length - 1] : null,
        sma50: sma50Values.length > 0 ? sma50Values[sma50Values.length - 1] : null,
        ema20: ema20Values.length > 0 ? ema20Values[ema20Values.length - 1] : null,
        bollingerBands: {
          upper: bbValues.length > 0 ? bbValues[bbValues.length - 1].upper : null,
          middle: bbValues.length > 0 ? bbValues[bbValues.length - 1].middle : null,
          lower: bbValues.length > 0 ? bbValues[bbValues.length - 1].lower : null,
        },
        volume: volumes[volumes.length - 1] || 0,
      };
    } catch (error) {
      console.error('Error calculating technical indicators:', error);
      return this.getEmptyResult(volumes[volumes.length - 1] || 0);
    }
  }

  generateTradingSignal(indicators: TechnicalIndicatorResult, currentPrice: number): {
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reasoning: string;
  } {
    const signals = [];
    let bullishCount = 0;
    let bearishCount = 0;

    // RSI analysis
    if (indicators.rsi !== null) {
      if (indicators.rsi < 30) {
        signals.push('RSI oversold - potential buy');
        bullishCount++;
      } else if (indicators.rsi > 70) {
        signals.push('RSI overbought - potential sell');
        bearishCount++;
      }
    }

    // MACD analysis
    if (indicators.macd.MACD !== null && indicators.macd.signal !== null) {
      if (indicators.macd.MACD > indicators.macd.signal) {
        signals.push('MACD bullish crossover');
        bullishCount++;
      } else {
        signals.push('MACD bearish crossover');
        bearishCount++;
      }
    }

    // Moving average analysis
    if (indicators.sma20 !== null && indicators.sma50 !== null) {
      if (currentPrice > indicators.sma20 && indicators.sma20 > indicators.sma50) {
        signals.push('Price above moving averages - uptrend');
        bullishCount++;
      } else if (currentPrice < indicators.sma20 && indicators.sma20 < indicators.sma50) {
        signals.push('Price below moving averages - downtrend');
        bearishCount++;
      }
    }

    // Bollinger Bands analysis
    if (indicators.bollingerBands.lower !== null && indicators.bollingerBands.upper !== null) {
      if (currentPrice <= indicators.bollingerBands.lower) {
        signals.push('Price at lower Bollinger Band - oversold');
        bullishCount++;
      } else if (currentPrice >= indicators.bollingerBands.upper) {
        signals.push('Price at upper Bollinger Band - overbought');
        bearishCount++;
      }
    }

    // Determine final signal
    let finalSignal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 50;

    if (bullishCount > bearishCount && bullishCount >= 2) {
      finalSignal = 'BUY';
      confidence = Math.min(95, 50 + (bullishCount - bearishCount) * 15);
    } else if (bearishCount > bullishCount && bearishCount >= 2) {
      finalSignal = 'SELL';
      confidence = Math.min(95, 50 + (bearishCount - bullishCount) * 15);
    }

    return {
      signal: finalSignal,
      confidence,
      reasoning: signals.length > 0 ? signals.join('; ') : 'No clear signals detected',
    };
  }

  calculateSupertrendSignal(prices: number[], highs: number[], lows: number[], period: number = 10, factor: number = 3): {
    supertrend: number;
    signal: 'BUY' | 'SELL' | 'HOLD';
  } {
    if (prices.length < period) {
      return { supertrend: prices[prices.length - 1] || 0, signal: 'HOLD' };
    }

    try {
      // Calculate ATR (Average True Range)
      const atr = this.calculateATR(highs, lows, prices, period);
      const hl2 = highs.map((high, i) => (high + lows[i]) / 2);
      
      const upperBand = hl2[hl2.length - 1] + (factor * atr);
      const lowerBand = hl2[hl2.length - 1] - (factor * atr);
      
      const currentPrice = prices[prices.length - 1];
      
      let supertrend = upperBand;
      let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
      
      if (currentPrice <= lowerBand) {
        supertrend = lowerBand;
        signal = 'BUY';
      } else if (currentPrice >= upperBand) {
        supertrend = upperBand;
        signal = 'SELL';
      }
      
      return { supertrend, signal };
    } catch (error) {
      console.error('Error calculating Supertrend:', error);
      return { supertrend: prices[prices.length - 1] || 0, signal: 'HOLD' };
    }
  }

  private calculateATR(highs: number[], lows: number[], closes: number[], period: number): number {
    const trueRanges = [];
    
    for (let i = 1; i < highs.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }
    
    const recentTR = trueRanges.slice(-period);
    return recentTR.reduce((sum, tr) => sum + tr, 0) / period;
  }

  private getEmptyResult(volume: number): TechnicalIndicatorResult {
    return {
      rsi: null,
      macd: { MACD: null, signal: null, histogram: null },
      sma20: null,
      sma50: null,
      ema20: null,
      bollingerBands: { upper: null, middle: null, lower: null },
      volume,
    };
  }
}

export const technicalIndicatorService = new TechnicalIndicatorService();
