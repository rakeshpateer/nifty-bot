import yahooFinance from 'yahoo-finance2';
import { storage } from '../storage';
import type { Stock, InsertStock, InsertStockPrice } from '@shared/schema';

interface YahooQuote {
  symbol: string;
  regularMarketPrice: number;
  regularMarketOpen: number;
  regularMarketDayHigh: number;
  regularMarketDayLow: number;
  regularMarketVolume: number;
  regularMarketChange: number;
  regularMarketChangePercent: number;
  shortName: string;
}

export class StockService {
  private static readonly INDIAN_STOCKS = [
    { symbol: 'RELIANCE.NS', name: 'Reliance Industries Limited', sector: 'Energy' },
    { symbol: 'HDFCBANK.NS', name: 'HDFC Bank Limited', sector: 'Banking' },
    { symbol: 'INFY.NS', name: 'Infosys Limited', sector: 'Information Technology' },
    { symbol: 'ICICIBANK.NS', name: 'ICICI Bank Limited', sector: 'Banking' },
    { symbol: 'TCS.NS', name: 'Tata Consultancy Services Limited', sector: 'Information Technology' },
    { symbol: 'BHARTIARTL.NS', name: 'Bharti Airtel Limited', sector: 'Telecommunications' },
    { symbol: 'ITC.NS', name: 'ITC Limited', sector: 'Consumer Goods' },
    { symbol: 'SBIN.NS', name: 'State Bank of India', sector: 'Banking' },
    { symbol: 'LT.NS', name: 'Larsen & Toubro Limited', sector: 'Construction' },
    { symbol: 'AXISBANK.NS', name: 'Axis Bank Limited', sector: 'Banking' },
    { symbol: 'KOTAKBANK.NS', name: 'Kotak Mahindra Bank Limited', sector: 'Banking' },
    { symbol: 'HINDUNILVR.NS', name: 'Hindustan Unilever Limited', sector: 'Consumer Goods' },
    { symbol: 'BAJFINANCE.NS', name: 'Bajaj Finance Limited', sector: 'Financial Services' },
    { symbol: 'ASIANPAINT.NS', name: 'Asian Paints Limited', sector: 'Chemicals' },
    { symbol: 'MARUTI.NS', name: 'Maruti Suzuki India Limited', sector: 'Automotive' },
    { symbol: 'M&M.NS', name: 'Mahindra & Mahindra Limited', sector: 'Automotive' },
    { symbol: 'HCLTECH.NS', name: 'HCL Technologies Limited', sector: 'Information Technology' },
    { symbol: 'SUNPHARMA.NS', name: 'Sun Pharmaceutical Industries Limited', sector: 'Pharmaceuticals' },
    { symbol: 'TITAN.NS', name: 'Titan Company Limited', sector: 'Consumer Goods' },
    { symbol: 'ULTRACEMCO.NS', name: 'UltraTech Cement Limited', sector: 'Cement' }
  ];

  async initializeStocks(): Promise<void> {
    try {
      for (const stockData of StockService.INDIAN_STOCKS) {
        const existingStock = await storage.getStock(stockData.symbol);
        if (!existingStock) {
          const newStock: InsertStock = {
            id: stockData.symbol.replace('.NS', ''),
            symbol: stockData.symbol,
            name: stockData.name,
            exchange: 'NSE',
            sector: stockData.sector,
            isActive: true,
          };
          await storage.createStock(newStock);
        }
      }
    } catch (error) {
      console.error('Error initializing stocks:', error);
    }
  }

  async fetchLivePrice(symbol: string): Promise<YahooQuote | null> {
    try {
      const quote = await yahooFinance.quote(symbol);
      return {
        symbol,
        regularMarketPrice: quote.regularMarketPrice || 0,
        regularMarketOpen: quote.regularMarketOpen || 0,
        regularMarketDayHigh: quote.regularMarketDayHigh || 0,
        regularMarketDayLow: quote.regularMarketDayLow || 0,
        regularMarketVolume: quote.regularMarketVolume || 0,
        regularMarketChange: quote.regularMarketChange || 0,
        regularMarketChangePercent: (quote.regularMarketChangePercent || 0) * 100,
        shortName: quote.shortName || symbol,
      };
    } catch (error) {
      console.error(`Error fetching price for ${symbol}:`, error);
      return null;
    }
  }

  async updateAllPrices(): Promise<void> {
    try {
      const stocks = await storage.getAllStocks();
      
      for (const stock of stocks) {
        const quote = await this.fetchLivePrice(stock.symbol);
        if (quote) {
          const priceData: InsertStockPrice = {
            stockId: stock.id,
            price: quote.regularMarketPrice.toString(),
            open: quote.regularMarketOpen.toString(),
            high: quote.regularMarketDayHigh.toString(),
            low: quote.regularMarketDayLow.toString(),
            volume: quote.regularMarketVolume,
            change: quote.regularMarketChange.toString(),
            changePercent: quote.regularMarketChangePercent.toString(),
          };
          await storage.createStockPrice(priceData);
        }
        
        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error('Error updating all prices:', error);
    }
  }

  async getHistoricalData(symbol: string, period: string = '1mo'): Promise<any[]> {
    try {
      const result = await yahooFinance.historical(symbol, {
        period1: this.getPeriodDate(period),
        period2: new Date(),
        interval: '1d',
      });
      return result;
    } catch (error) {
      console.error(`Error fetching historical data for ${symbol}:`, error);
      return [];
    }
  }

  private getPeriodDate(period: string): Date {
    const now = new Date();
    switch (period) {
      case '1d': return new Date(now.getTime() - 24 * 60 * 60 * 1000);
      case '5d': return new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
      case '1mo': return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      case '3mo': return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      case '1y': return new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
      default: return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }
  }

  async getMarketIndices(): Promise<{ nifty: any, banknifty: any, sensex: any }> {
    try {
      const [nifty, banknifty, sensex] = await Promise.all([
        this.fetchLivePrice('^NSEI'),
        this.fetchLivePrice('^NSEBANK'),
        this.fetchLivePrice('^BSESN')
      ]);

      return {
        nifty: nifty || { regularMarketPrice: 0, regularMarketChangePercent: 0 },
        banknifty: banknifty || { regularMarketPrice: 0, regularMarketChangePercent: 0 },
        sensex: sensex || { regularMarketPrice: 0, regularMarketChangePercent: 0 }
      };
    } catch (error) {
      console.error('Error fetching market indices:', error);
      return {
        nifty: { regularMarketPrice: 0, regularMarketChangePercent: 0 },
        banknifty: { regularMarketPrice: 0, regularMarketChangePercent: 0 },
        sensex: { regularMarketPrice: 0, regularMarketChangePercent: 0 }
      };
    }
  }
}

export const stockService = new StockService();
