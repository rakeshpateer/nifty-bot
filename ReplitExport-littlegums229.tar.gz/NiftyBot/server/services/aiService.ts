import { storage } from '../storage';
import { stockService } from './stockService';
import type { InsertMarketSentiment, InsertTradingSignal } from '@shared/schema';

export interface NewsItem {
  title: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: number; // 0-1 scale
  source: string;
}

export interface SectorPerformance {
  name: string;
  change: number;
  stocks: string[];
}

export class AIService {
  private readonly sectorMapping = {
    'Banking': ['HDFCBANK.NS', 'ICICIBANK.NS', 'SBIN.NS', 'AXISBANK.NS', 'KOTAKBANK.NS'],
    'Information Technology': ['INFY.NS', 'TCS.NS', 'HCLTECH.NS'],
    'Energy': ['RELIANCE.NS'],
    'Telecommunications': ['BHARTIARTL.NS'],
    'Consumer Goods': ['ITC.NS', 'HINDUNILVR.NS', 'TITAN.NS'],
    'Automotive': ['MARUTI.NS', 'M&M.NS'],
    'Financial Services': ['BAJFINANCE.NS'],
    'Pharmaceuticals': ['SUNPHARMA.NS'],
    'Chemicals': ['ASIANPAINT.NS'],
    'Construction': ['LT.NS'],
    'Cement': ['ULTRACEMCO.NS']
  };

  async analyzeMarketSentiment(): Promise<void> {
    try {
      // Fetch market indices for overall sentiment
      const indices = await stockService.getMarketIndices();
      
      // Calculate overall sentiment based on index performance
      const niftyChange = indices.nifty.regularMarketChangePercent || 0;
      const sensexChange = indices.sensex.regularMarketChangePercent || 0;
      const bankNiftyChange = indices.banknifty.regularMarketChangePercent || 0;
      
      const overallChange = (niftyChange + sensexChange + bankNiftyChange) / 3;
      
      // Convert to sentiment score (0-100)
      let sentimentScore = 50 + (overallChange * 10); // Scale change to sentiment
      sentimentScore = Math.max(0, Math.min(100, sentimentScore));
      
      const bullishPercent = sentimentScore;
      const bearishPercent = 100 - sentimentScore;
      
      // Analyze sector performance
      const sectorPerformance = await this.analyzeSectorPerformance();
      
      // Generate mock news analysis (in production, integrate with news APIs)
      const newsAnalysis = this.generateNewsAnalysis(overallChange);
      
      const sentimentData: InsertMarketSentiment = {
        overall: sentimentScore.toString(),
        bullishPercent: bullishPercent.toString(),
        bearishPercent: bearishPercent.toString(),
        newsAnalysis: JSON.stringify(newsAnalysis),
        sectorPerformance: JSON.stringify(sectorPerformance),
      };
      
      await storage.createMarketSentiment(sentimentData);
    } catch (error) {
      console.error('Error analyzing market sentiment:', error);
    }
  }

  async generateTradingSignals(): Promise<void> {
    try {
      const stocks = await storage.getAllStocks();
      
      for (const stock of stocks.slice(0, 10)) { // Process first 10 stocks
        try {
          // Get historical data for technical analysis
          const historicalData = await stockService.getHistoricalData(stock.symbol, '3mo');
          
          if (historicalData.length < 20) continue;
          
          const prices = historicalData.map(d => d.close);
          const volumes = historicalData.map(d => d.volume);
          
          // Simple signal generation based on price movement
          const recentPrices = prices.slice(-10);
          const averagePrice = recentPrices.reduce((sum, price) => sum + price, 0) / recentPrices.length;
          const currentPrice = prices[prices.length - 1];
          
          const priceChange = ((currentPrice - averagePrice) / averagePrice) * 100;
          const volumeRatio = volumes[volumes.length - 1] / (volumes.slice(-10).reduce((sum, v) => sum + v, 0) / 10);
          
          let signalType: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
          let confidence = 50;
          let reasoning = 'No clear trend detected';
          
          if (priceChange > 2 && volumeRatio > 1.2) {
            signalType = 'BUY';
            confidence = Math.min(85, 60 + priceChange * 2);
            reasoning = `Strong upward momentum with ${priceChange.toFixed(2)}% price increase and ${volumeRatio.toFixed(2)}x volume surge`;
          } else if (priceChange < -2 && volumeRatio > 1.2) {
            signalType = 'SELL';
            confidence = Math.min(85, 60 + Math.abs(priceChange) * 2);
            reasoning = `Downward pressure with ${priceChange.toFixed(2)}% price decline and increased volume`;
          } else if (Math.abs(priceChange) < 1) {
            signalType = 'HOLD';
            confidence = 65;
            reasoning = 'Consolidation phase, await clearer direction';
          }
          
          const targetPrice = signalType === 'BUY' ? 
            currentPrice * 1.05 : 
            signalType === 'SELL' ? 
              currentPrice * 0.95 : 
              currentPrice;
          
          const stopLoss = signalType === 'BUY' ? 
            currentPrice * 0.97 : 
            signalType === 'SELL' ? 
              currentPrice * 1.03 : 
              currentPrice * 0.95;
          
          const signalData: InsertTradingSignal = {
            stockId: stock.id,
            type: signalType,
            confidence: confidence.toString(),
            targetPrice: targetPrice.toString(),
            stopLoss: stopLoss.toString(),
            reasoning,
            indicators: JSON.stringify({
              priceChange: priceChange.toFixed(2),
              volumeRatio: volumeRatio.toFixed(2),
              currentPrice: currentPrice.toFixed(2)
            }),
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // Expires in 24 hours
          };
          
          await storage.createTradingSignal(signalData);
          
        } catch (stockError) {
          console.error(`Error processing stock ${stock.symbol}:`, stockError);
        }
        
        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    } catch (error) {
      console.error('Error generating trading signals:', error);
    }
  }

  private async analyzeSectorPerformance(): Promise<SectorPerformance[]> {
    const sectorPerformances: SectorPerformance[] = [];
    
    for (const [sectorName, symbols] of Object.entries(this.sectorMapping)) {
      try {
        const sectorChanges = [];
        
        for (const symbol of symbols) {
          const quote = await stockService.fetchLivePrice(symbol);
          if (quote) {
            sectorChanges.push(quote.regularMarketChangePercent);
          }
        }
        
        if (sectorChanges.length > 0) {
          const averageChange = sectorChanges.reduce((sum, change) => sum + change, 0) / sectorChanges.length;
          sectorPerformances.push({
            name: sectorName,
            change: Number(averageChange.toFixed(2)),
            stocks: symbols
          });
        }
      } catch (error) {
        console.error(`Error analyzing sector ${sectorName}:`, error);
      }
    }
    
    return sectorPerformances.sort((a, b) => b.change - a.change);
  }

  private generateNewsAnalysis(overallChange: number): NewsItem[] {
    // In production, this would integrate with news APIs and perform NLP sentiment analysis
    const newsItems: NewsItem[] = [];
    
    if (overallChange > 1) {
      newsItems.push({
        title: 'Strong Q3 earnings from IT sector driving positive sentiment',
        sentiment: 'positive',
        impact: 0.8,
        source: 'Market Analysis'
      });
      newsItems.push({
        title: 'FII inflows continue, supporting market momentum',
        sentiment: 'positive',
        impact: 0.7,
        source: 'Financial Times'
      });
    } else if (overallChange < -1) {
      newsItems.push({
        title: 'Rising inflation concerns weigh on market sentiment',
        sentiment: 'negative',
        impact: 0.7,
        source: 'Economic Times'
      });
      newsItems.push({
        title: 'Global uncertainty impacts emerging markets',
        sentiment: 'negative',
        impact: 0.6,
        source: 'Reuters'
      });
    }
    
    newsItems.push({
      title: 'RBI policy decision pending, markets cautious',
      sentiment: 'neutral',
      impact: 0.5,
      source: 'Business Standard'
    });
    
    return newsItems;
  }

  async calculatePortfolioRisk(userId: string): Promise<{
    beta: number;
    maxDrawdown: number;
    sharpeRatio: number;
    volatility: number;
  }> {
    try {
      // This is a simplified risk calculation
      // In production, implement proper portfolio risk metrics
      
      const trades = await storage.getUserTrades(userId, 100);
      
      if (trades.length < 10) {
        return {
          beta: 1.0,
          maxDrawdown: 0,
          sharpeRatio: 0,
          volatility: 0
        };
      }
      
      // Calculate simple risk metrics
      const returns = trades.slice(1).map((trade, i) => {
        const prevAmount = Number(trades[i].amount);
        const currentAmount = Number(trade.amount);
        return (currentAmount - prevAmount) / prevAmount;
      });
      
      const avgReturn = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
      const volatility = Math.sqrt(
        returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / returns.length
      );
      
      // Simple drawdown calculation
      let maxDrawdown = 0;
      let peak = Number(trades[0].amount);
      
      for (const trade of trades) {
        const amount = Number(trade.amount);
        if (amount > peak) {
          peak = amount;
        } else {
          const drawdown = (peak - amount) / peak;
          maxDrawdown = Math.max(maxDrawdown, drawdown);
        }
      }
      
      return {
        beta: Math.max(0.5, Math.min(1.5, 1.0 + (volatility - 0.15) * 2)), // Simplified beta
        maxDrawdown: maxDrawdown * 100,
        sharpeRatio: volatility > 0 ? avgReturn / volatility : 0,
        volatility: volatility * 100
      };
    } catch (error) {
      console.error('Error calculating portfolio risk:', error);
      return { beta: 1.0, maxDrawdown: 0, sharpeRatio: 0, volatility: 0 };
    }
  }
}

export const aiService = new AIService();
