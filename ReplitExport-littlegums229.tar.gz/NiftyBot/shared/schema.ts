import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  decimal,
  integer,
  text,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const stocks = pgTable("stocks", {
  id: varchar("id").primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  exchange: varchar("exchange", { length: 10 }).notNull().default('NSE'),
  sector: varchar("sector", { length: 100 }),
  marketCap: decimal("market_cap", { precision: 15, scale: 2 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stockPrices = pgTable("stock_prices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  open: decimal("open", { precision: 10, scale: 2 }),
  high: decimal("high", { precision: 10, scale: 2 }),
  low: decimal("low", { precision: 10, scale: 2 }),
  volume: integer("volume"),
  change: decimal("change", { precision: 10, scale: 2 }),
  changePercent: decimal("change_percent", { precision: 5, scale: 2 }),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const portfolios = pgTable("portfolios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: varchar("name", { length: 100 }).notNull().default('Default Portfolio'),
  totalValue: decimal("total_value", { precision: 15, scale: 2 }).default('0'),
  totalInvested: decimal("total_invested", { precision: 15, scale: 2 }).default('0'),
  todayPnL: decimal("today_pnl", { precision: 15, scale: 2 }).default('0'),
  totalPnL: decimal("total_pnl", { precision: 15, scale: 2 }).default('0'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  portfolioId: varchar("portfolio_id").notNull().references(() => portfolios.id),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  type: varchar("type", { length: 10 }).notNull(), // 'BUY' or 'SELL'
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  fees: decimal("fees", { precision: 10, scale: 2 }).default('0'),
  pnl: decimal("pnl", { precision: 15, scale: 2 }),
  executedAt: timestamp("executed_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const watchlists = pgTable("watchlists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  addedAt: timestamp("added_at").defaultNow(),
});

export const tradingSignals = pgTable("trading_signals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  type: varchar("type", { length: 10 }).notNull(), // 'BUY', 'SELL', 'HOLD'
  confidence: decimal("confidence", { precision: 5, scale: 2 }),
  targetPrice: decimal("target_price", { precision: 10, scale: 2 }),
  stopLoss: decimal("stop_loss", { precision: 10, scale: 2 }),
  reasoning: text("reasoning"),
  indicators: jsonb("indicators"), // Technical indicator values
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const marketSentiment = pgTable("market_sentiment", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  overall: decimal("overall", { precision: 5, scale: 2 }),
  bullishPercent: decimal("bullish_percent", { precision: 5, scale: 2 }),
  bearishPercent: decimal("bearish_percent", { precision: 5, scale: 2 }),
  newsAnalysis: jsonb("news_analysis"),
  sectorPerformance: jsonb("sector_performance"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema validation types
export const insertUserSchema = createInsertSchema(users);
export const insertStockSchema = createInsertSchema(stocks);
export const insertPortfolioSchema = createInsertSchema(portfolios);
export const insertTradeSchema = createInsertSchema(trades);
export const insertWatchlistSchema = createInsertSchema(watchlists);

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Stock = typeof stocks.$inferSelect;
export type InsertStock = typeof stocks.$inferInsert;
export type StockPrice = typeof stockPrices.$inferSelect;
export type InsertStockPrice = typeof stockPrices.$inferInsert;
export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = typeof portfolios.$inferInsert;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;
export type Watchlist = typeof watchlists.$inferSelect;
export type InsertWatchlist = typeof watchlists.$inferInsert;
export type TradingSignal = typeof tradingSignals.$inferSelect;
export type InsertTradingSignal = typeof tradingSignals.$inferInsert;
export type MarketSentiment = typeof marketSentiment.$inferSelect;
export type InsertMarketSentiment = typeof marketSentiment.$inferInsert;
