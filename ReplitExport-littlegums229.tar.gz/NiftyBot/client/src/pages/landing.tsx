import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, Brain, Shield, TrendingUp } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/50">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <BarChart3 className="text-primary-foreground" size={16} />
              </div>
              <span className="font-bold text-xl">StockSense AI</span>
            </div>
            <Button onClick={() => window.location.href = '/api/login'} data-testid="button-login">
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            AI-Powered Indian Stock Trading Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Trade smarter with real-time analysis, AI-generated signals, and comprehensive portfolio management 
            for NSE, BSE, Nifty 50, and Bank Nifty stocks.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-get-started"
            >
              Get Started Free
            </Button>
            <Button variant="outline" size="lg" data-testid="button-learn-more">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Powerful Features for Smart Trading</h2>
          <p className="text-muted-foreground text-lg">
            Everything you need to make informed trading decisions in the Indian stock market
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Real-time Data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="text-primary" />
                <span>Real-time Data</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Live prices, charts, and market data from NSE/BSE with technical indicators 
                including RSI, MACD, and Bollinger Bands.
              </p>
            </CardContent>
          </Card>

          {/* AI Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="text-primary" />
                <span>AI Market Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Advanced sentiment analysis, news processing, and machine learning algorithms 
                to generate intelligent trading signals.
              </p>
            </CardContent>
          </Card>

          {/* Risk Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="text-primary" />
                <span>Risk Management</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Dynamic stop-loss, position sizing calculator, portfolio beta analysis, 
                and daily loss limits to protect your capital.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Market Coverage */}
      <section className="bg-muted/50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Complete Market Coverage</h2>
            <p className="text-muted-foreground text-lg">
              Trade across all major Indian stock indices and sectors
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-secondary-foreground font-bold text-xl">50</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Nifty 50</h3>
              <p className="text-muted-foreground">
                Top 50 companies by market capitalization including Reliance, HDFC Bank, Infosys, and TCS
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-accent-foreground font-bold text-xl">BN</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Bank Nifty</h3>
              <p className="text-muted-foreground">
                Banking sector stocks including HDFC Bank, ICICI Bank, SBI, and Axis Bank
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-primary-foreground font-bold text-xl">30</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Sensex</h3>
              <p className="text-muted-foreground">
                BSE Sensex 30 stocks representing diverse sectors of the Indian economy
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">Start Your Smart Trading Journey</h2>
          <p className="text-muted-foreground text-lg mb-8">
            Join thousands of traders who are already using AI-powered insights to make better investment decisions
          </p>
          <Button 
            size="lg" 
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-start-trading"
          >
            Start Trading Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground text-sm">
            <p className="mb-2">
              ⚠️ SEBI Disclaimer: Trading in securities is subject to market risks. 
              Please read all related documents carefully before investing.
            </p>
            <p>
              © 2024 StockSense AI. This platform is for educational and informational purposes. 
              Not a registered investment advisor.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
