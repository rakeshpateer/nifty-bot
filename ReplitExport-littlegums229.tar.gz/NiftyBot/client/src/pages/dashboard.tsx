import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { MarketOverview } from '@/components/dashboard/market-overview';
import { AISentiment } from '@/components/dashboard/ai-sentiment';
import { RiskManagement } from '@/components/dashboard/risk-management';
import { StockChart } from '@/components/ui/stock-chart';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import { ExpandIcon, Plus } from 'lucide-react';
import { useEffect } from 'react';

interface Stock {
  id: string;
  symbol: string;
  name: string;
  latestPrice?: {
    price: string;
    changePercent: string;
  };
}

interface Trade {
  id: string;
  type: 'BUY' | 'SELL';
  quantity: number;
  price: string;
  amount: string;
  pnl?: string;
  executedAt: string;
  stock?: {
    symbol: string;
    name: string;
  };
}

interface TechnicalIndicators {
  indicators: {
    rsi: number | null;
    macd: {
      MACD: number | null;
      signal: number | null;
      histogram: number | null;
    };
    sma20: number | null;
    sma50: number | null;
    ema20: number | null;
    bollingerBands: {
      upper: number | null;
      middle: number | null;
      lower: number | null;
    };
    volume: number;
  };
  supertrend: {
    supertrend: number;
    signal: 'BUY' | 'SELL' | 'HOLD';
  };
  signal: {
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reasoning: string;
  };
}

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedStock, setSelectedStock] = useState('RELIANCE');
  const [timeframe, setTimeframe] = useState('1D');

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, toast]);

  const { data: stocks } = useQuery<Stock[]>({
    queryKey: ['/api/stocks'],
    enabled: !!user,
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  const { data: historicalData } = useQuery({
    queryKey: ['/api/stocks', selectedStock, 'historical', timeframe.toLowerCase()],
    enabled: !!selectedStock,
  });

  const { data: indicators } = useQuery<TechnicalIndicators>({
    queryKey: ['/api/stocks', selectedStock, 'indicators'],
    enabled: !!selectedStock,
  });

  const { data: recentTrades } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
    enabled: !!user,
  });

  const formatHistoricalData = (data: any[]) => {
    if (!data || !Array.isArray(data)) return [];
    return data.map((item) => ({
      date: new Date(item.date).toISOString().split('T')[0],
      open: item.open,
      high: item.high,
      low: item.low,
      close: item.close,
      volume: item.volume,
    }));
  };

  const getTimeframePeriod = (timeframe: string) => {
    const mapping: { [key: string]: string } = {
      '1D': '1d',
      '5D': '5d',
      '1M': '1mo',
      '3M': '3mo',
      '1Y': '1y',
    };
    return mapping[timeframe] || '1mo';
  };

  if (!user) {
    return null; // Will redirect to login
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex">
        <Sidebar />
        
        {/* Main Content */}
        <main className="flex-1 p-6 space-y-6 overflow-y-auto">
          {/* Market Overview */}
          <MarketOverview />

          {/* Main Chart Section */}
          <Card>
            <CardHeader className="border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <CardTitle>Chart Analysis</CardTitle>
                  <Select value={selectedStock} onValueChange={setSelectedStock}>
                    <SelectTrigger className="w-40" data-testid="select-stock">
                      <SelectValue placeholder="Select stock" />
                    </SelectTrigger>
                    <SelectContent>
                      {stocks?.map((stock) => (
                        <SelectItem key={stock.id} value={stock.symbol.replace('.NS', '')}>
                          {stock.symbol.replace('.NS', '')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <Tabs value={timeframe} onValueChange={setTimeframe} className="w-auto">
                    <TabsList className="grid grid-cols-5 w-fit">
                      <TabsTrigger value="1D" className="text-xs">1D</TabsTrigger>
                      <TabsTrigger value="5D" className="text-xs">5D</TabsTrigger>
                      <TabsTrigger value="1M" className="text-xs">1M</TabsTrigger>
                      <TabsTrigger value="3M" className="text-xs">3M</TabsTrigger>
                      <TabsTrigger value="1Y" className="text-xs">1Y</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  <Button variant="ghost" size="sm" data-testid="button-expand-chart">
                    <ExpandIcon className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-6">
              {/* Chart Container */}
              <StockChart 
                data={formatHistoricalData(historicalData)} 
                symbol={selectedStock}
                className="h-96 w-full"
              />

              {/* Technical Indicators */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="bg-muted rounded-md p-3">
                  <div className="text-xs text-muted-foreground mb-1">RSI (14)</div>
                  <div className="font-mono text-sm font-medium" data-testid="indicator-rsi">
                    {indicators?.indicators.rsi?.toFixed(2) || '--'}
                  </div>
                  <div className="text-xs text-orange-600">
                    {indicators?.indicators.rsi && indicators.indicators.rsi > 70 ? 'Overbought' : 
                     indicators?.indicators.rsi && indicators.indicators.rsi < 30 ? 'Oversold' : 'Neutral'}
                  </div>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <div className="text-xs text-muted-foreground mb-1">MACD</div>
                  <div className="font-mono text-sm font-medium" data-testid="indicator-macd">
                    {indicators?.indicators.macd.MACD?.toFixed(2) || '--'}
                  </div>
                  <div className={`text-xs ${
                    indicators?.indicators.macd.MACD && indicators.indicators.macd.signal &&
                    indicators.indicators.macd.MACD > indicators.indicators.macd.signal
                      ? 'text-secondary' : 'text-destructive'
                  }`}>
                    {indicators?.indicators.macd.MACD && indicators.indicators.macd.signal
                      ? indicators.indicators.macd.MACD > indicators.indicators.macd.signal ? 'Bullish' : 'Bearish'
                      : 'Neutral'}
                  </div>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <div className="text-xs text-muted-foreground mb-1">Volume</div>
                  <div className="font-mono text-sm font-medium" data-testid="indicator-volume">
                    {indicators?.indicators.volume 
                      ? `${(indicators.indicators.volume / 1000000).toFixed(1)}M` 
                      : '--'}
                  </div>
                  <div className="text-xs text-accent">Above Avg</div>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <div className="text-xs text-muted-foreground mb-1">Supertrend</div>
                  <div className="font-mono text-sm font-medium" data-testid="indicator-supertrend">
                    ₹{indicators?.supertrend.supertrend?.toFixed(2) || '--'}
                  </div>
                  <div className={`text-xs ${
                    indicators?.supertrend.signal === 'BUY' ? 'text-secondary' : 
                    indicators?.supertrend.signal === 'SELL' ? 'text-destructive' : 'text-accent'
                  }`}>
                    {indicators?.supertrend.signal || 'Hold'} Signal
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Analysis and Risk Management */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AISentiment />
            <RiskManagement />
          </div>

          {/* Recent Trades and Backtest Results */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Trades */}
            <Card className="lg:col-span-2">
              <CardHeader className="border-b border-border">
                <div className="flex items-center justify-between">
                  <CardTitle>Recent Trades</CardTitle>
                  <Button variant="ghost" size="sm" data-testid="button-view-all-trades">
                    View All
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr className="text-left">
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Stock</th>
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Type</th>
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Qty</th>
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Price</th>
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">P&L</th>
                        <th className="px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Time</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {recentTrades && recentTrades.length > 0 ? (
                        recentTrades.slice(0, 5).map((trade) => (
                          <tr key={trade.id} className="hover:bg-muted/30 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="font-medium text-sm">
                                {trade.stock?.symbol?.replace('.NS', '') || 'Unknown'}
                              </div>
                              <div className="text-xs text-muted-foreground truncate max-w-32">
                                {trade.stock?.name || 'Unknown Stock'}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge 
                                variant={trade.type === 'BUY' ? 'secondary' : 'destructive'}
                                className="text-xs"
                              >
                                {trade.type}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap font-mono text-sm">
                              {trade.quantity}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap font-mono text-sm">
                              ₹{parseFloat(trade.price).toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap font-mono text-sm">
                              {trade.pnl ? (
                                <span className={parseFloat(trade.pnl) >= 0 ? 'text-secondary' : 'text-destructive'}>
                                  {parseFloat(trade.pnl) >= 0 ? '+' : ''}₹{parseFloat(trade.pnl).toFixed(0)}
                                </span>
                              ) : '--'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-xs text-muted-foreground">
                              {new Date(trade.executedAt).toLocaleDateString('en-IN')}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                            No trades found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Backtest Results */}
            <Card>
              <CardHeader>
                <CardTitle>Backtest Results</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-md p-4">
                  <div className="text-sm text-muted-foreground mb-1">Strategy Performance</div>
                  <div className="text-xl font-bold text-secondary" data-testid="backtest-total-return">
                    +23.45%
                  </div>
                  <div className="text-xs text-muted-foreground">Last 6 months</div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <div className="text-sm font-mono font-semibold" data-testid="backtest-win-rate">68%</div>
                    <div className="text-xs text-muted-foreground">Win Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-mono font-semibold" data-testid="backtest-sharpe-ratio">1.47</div>
                    <div className="text-xs text-muted-foreground">Sharpe Ratio</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <div className="text-sm font-mono font-semibold text-secondary" data-testid="backtest-max-profit">+₹8,945</div>
                    <div className="text-xs text-muted-foreground">Max Profit</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-mono font-semibold text-destructive" data-testid="backtest-max-loss">-₹2,134</div>
                    <div className="text-xs text-muted-foreground">Max Loss</div>
                  </div>
                </div>

                <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90" data-testid="button-run-backtest">
                  Run New Backtest
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* Mobile FAB */}
      <div className="fixed bottom-4 right-4 md:hidden">
        <Button size="lg" className="w-14 h-14 rounded-full shadow-lg" data-testid="button-mobile-add">
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      {/* SEBI Disclaimer */}
      <div className="fixed bottom-0 left-0 right-0 bg-muted border-t border-border p-2 text-xs text-center text-muted-foreground">
        <span>⚠️ SEBI Disclaimer: Trading in securities is subject to market risks. Please read all related documents carefully before investing.</span>
        <Button variant="ghost" size="sm" className="ml-2 text-accent hover:text-accent/80" data-testid="button-hide-disclaimer">
          Hide
        </Button>
      </div>
    </div>
  );
}
