import React, { useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist';

interface StockChartProps {
  data: Array<{
    date: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume?: number;
  }>;
  symbol: string;
  className?: string;
}

export function StockChart({ data, symbol, className = "" }: StockChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chartRef.current || !data.length) return;

    const trace = {
      x: data.map(d => d.date),
      open: data.map(d => d.open),
      high: data.map(d => d.high),
      low: data.map(d => d.low),
      close: data.map(d => d.close),
      type: 'candlestick' as const,
      name: symbol,
      increasing: { line: { color: 'hsl(123, 38%, 35%)' } },
      decreasing: { line: { color: 'hsl(0, 65%, 48%)' } },
    };

    const layout = {
      title: {
        text: `${symbol} - Price Chart`,
        font: { family: 'Inter, sans-serif', size: 16 },
      },
      xaxis: {
        title: 'Time',
        type: 'date' as const,
        gridcolor: 'hsl(0, 0%, 90%)',
      },
      yaxis: {
        title: 'Price (₹)',
        gridcolor: 'hsl(0, 0%, 90%)',
      },
      plot_bgcolor: 'transparent',
      paper_bgcolor: 'transparent',
      font: { 
        family: 'Inter, sans-serif',
        color: 'hsl(0, 0%, 15%)',
      },
      margin: { t: 50, b: 50, l: 60, r: 20 },
    };

    const config = {
      responsive: true,
      displayModeBar: false,
    };

    Plotly.newPlot(chartRef.current, [trace], layout, config);

    return () => {
      if (chartRef.current) {
        Plotly.purge(chartRef.current);
      }
    };
  }, [data, symbol]);

  return (
    <div 
      ref={chartRef} 
      className={`w-full h-96 ${className}`}
      data-testid="stock-chart"
    />
  );
}
