import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Bot } from 'lucide-react';
import { PortfolioSummary } from '../dashboard/portfolio-summary';
import { Watchlist } from '../dashboard/watchlist';
import { TradingSignals } from '../dashboard/trading-signals';

export function Sidebar() {
  return (
    <aside className="w-80 bg-card border-r border-border p-4 space-y-6 overflow-y-auto">
      {/* Portfolio Summary */}
      <PortfolioSummary />

      {/* Quick Actions */}
      <div className="space-y-2">
        <Button 
          className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
          data-testid="button-add-to-watchlist"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add to Watchlist
        </Button>
        <Button 
          className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
          data-testid="button-ai-recommendations"
        >
          <Bot className="w-4 h-4 mr-2" />
          AI Recommendations
        </Button>
      </div>

      {/* Watchlist */}
      <Watchlist />

      {/* Trading Signals */}
      <TradingSignals />
    </aside>
  );
}
