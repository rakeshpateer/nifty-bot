import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Bell, ChevronDown, BarChart3 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface MarketData {
  nifty: { regularMarketPrice: number; regularMarketChangePercent: number };
  sensex: { regularMarketPrice: number; regularMarketChangePercent: number };
}

export function Header() {
  const { user, isLoading: authLoading } = useAuth();
  
  const { data: marketData } = useQuery<MarketData>({
    queryKey: ['/api/market/indices'],
    refetchInterval: 30000,
  });

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="px-4 lg:px-6">
        <div className="flex h-16 items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <BarChart3 className="text-primary-foreground" size={16} />
              </div>
              <span className="font-bold text-xl">StockSense AI</span>
            </div>
            
            {/* Market Status Indicator */}
            <div className="hidden md:flex items-center space-x-2 ml-8">
              <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
              <span className="text-sm font-medium">Market Open</span>
              <span className="text-xs text-muted-foreground">NSE: 09:15 - 15:30</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#" className="text-sm font-medium text-primary border-b-2 border-primary pb-1">Dashboard</a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Portfolio</a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Signals</a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Backtest</a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Analysis</a>
          </nav>

          {/* User Menu and Actions */}
          <div className="flex items-center space-x-4">
            {/* Market Indices Quick View */}
            {marketData && (
              <div className="hidden lg:flex items-center space-x-4 bg-muted px-3 py-1 rounded-md">
                <div className="text-xs">
                  <span className="font-medium">NIFTY</span>
                  <span className="text-secondary ml-1">
                    {marketData.nifty.regularMarketPrice.toFixed(2)}
                  </span>
                  <span className={`text-xs ml-1 ${
                    marketData.nifty.regularMarketChangePercent >= 0 ? 'text-secondary' : 'text-destructive'
                  }`}>
                    {marketData.nifty.regularMarketChangePercent >= 0 ? '+' : ''}
                    {marketData.nifty.regularMarketChangePercent.toFixed(2)}%
                  </span>
                </div>
                <div className="text-xs">
                  <span className="font-medium">SENSEX</span>
                  <span className="text-secondary ml-1">
                    {marketData.sensex.regularMarketPrice.toFixed(2)}
                  </span>
                  <span className={`text-xs ml-1 ${
                    marketData.sensex.regularMarketChangePercent >= 0 ? 'text-secondary' : 'text-destructive'
                  }`}>
                    {marketData.sensex.regularMarketChangePercent >= 0 ? '+' : ''}
                    {marketData.sensex.regularMarketChangePercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            )}

            {/* Notifications */}
            <Button variant="ghost" size="sm" className="relative p-2" data-testid="button-notifications">
              <Bell size={16} />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
                3
              </span>
            </Button>

            {/* User Avatar and Menu */}
            {authLoading ? (
              <div className="flex items-center space-x-2 animate-pulse">
                <div className="w-8 h-8 bg-muted rounded-full"></div>
                <div className="hidden md:block h-4 bg-muted rounded w-20"></div>
              </div>
            ) : user ? (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  {user.firstName?.charAt(0) || user.email?.charAt(0) || 'U'}
                </div>
                <span className="hidden md:block text-sm font-medium">
                  {user.firstName || user.email?.split('@')[0] || 'User'}
                </span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <ChevronDown size={12} />
                </Button>
              </div>
            ) : (
              <Button onClick={() => window.location.href = '/api/login'} data-testid="button-login">
                Login
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
