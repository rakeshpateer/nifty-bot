import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketData {
  nifty: { regularMarketPrice: number; regularMarketChangePercent: number };
  banknifty: { regularMarketPrice: number; regularMarketChangePercent: number };
  sensex: { regularMarketPrice: number; regularMarketChangePercent: number };
}

export function MarketOverview() {
  const { data: marketData, isLoading } = useQuery<MarketData>({
    queryKey: ['/api/market/indices'],
    refetchInterval: 30000, // Update every 30 seconds
  });

  if (isLoading) {
    return (
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-muted rounded w-1/2 mb-4"></div>
              <div className="h-8 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-muted rounded w-1/3"></div>
            </CardContent>
          </Card>
        ))}
      </section>
    );
  }

  if (!marketData) {
    return (
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-destructive/20">
          <CardContent className="p-6 text-center">
            <p className="text-destructive">Failed to load market data</p>
          </CardContent>
        </Card>
      </section>
    );
  }

  const indices = [
    {
      name: 'NIFTY 50',
      data: marketData.nifty,
      icon: TrendingUp,
      color: 'text-secondary',
    },
    {
      name: 'BANK NIFTY',
      data: marketData.banknifty,
      icon: TrendingUp,
      color: 'text-accent',
    },
    {
      name: 'SENSEX',
      data: marketData.sensex,
      icon: TrendingUp,
      color: 'text-primary',
    },
  ];

  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {indices.map((index) => {
        const isPositive = index.data.regularMarketChangePercent >= 0;
        const Icon = isPositive ? TrendingUp : TrendingDown;
        
        return (
          <Card key={index.name} data-testid={`market-card-${index.name.toLowerCase().replace(' ', '-')}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">{index.name}</h3>
                <Icon className={isPositive ? 'text-secondary' : 'text-destructive'} size={20} />
              </div>
              <div className="space-y-2">
                <div className="text-2xl font-bold font-mono" data-testid={`price-${index.name.toLowerCase().replace(' ', '-')}`}>
                  ₹{index.data.regularMarketPrice.toLocaleString('en-IN', { 
                    minimumFractionDigits: 2, 
                    maximumFractionDigits: 2 
                  })}
                </div>
                <div className="flex items-center space-x-2">
                  <span 
                    className={`text-sm font-medium ${isPositive ? 'text-secondary' : 'text-destructive'}`}
                    data-testid={`change-${index.name.toLowerCase().replace(' ', '-')}`}
                  >
                    {isPositive ? '+' : ''}{index.data.regularMarketChangePercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </section>
  );
}
