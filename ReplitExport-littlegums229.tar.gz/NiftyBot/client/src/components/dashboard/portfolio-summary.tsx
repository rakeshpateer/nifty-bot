import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface Portfolio {
  id: string;
  totalValue: string;
  totalInvested: string;
  todayPnL: string;
  totalPnL: string;
}

export function PortfolioSummary() {
  const { user } = useAuth();
  
  const { data: portfolio, isLoading } = useQuery<Portfolio>({
    queryKey: ['/api/portfolio'],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="bg-gradient-to-r from-primary to-orange-600 rounded-lg p-4 text-white animate-pulse">
        <h3 className="font-semibold mb-2">Portfolio Value</h3>
        <div className="space-y-2">
          <div className="h-8 bg-white/20 rounded w-3/4"></div>
          <div className="h-4 bg-white/20 rounded w-1/2"></div>
          <div className="h-4 bg-white/20 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="bg-gradient-to-r from-primary to-orange-600 rounded-lg p-4 text-white">
        <h3 className="font-semibold mb-2">Portfolio Value</h3>
        <div className="text-center py-4">
          <p className="text-white/80">No portfolio data available</p>
        </div>
      </div>
    );
  }

  const totalValue = parseFloat(portfolio.totalValue);
  const todayPnL = parseFloat(portfolio.todayPnL);
  const totalPnL = parseFloat(portfolio.totalPnL);
  const todayPnLPercent = totalValue > 0 ? (todayPnL / totalValue) * 100 : 0;
  const totalPnLPercent = totalValue > 0 ? (totalPnL / totalValue) * 100 : 0;

  return (
    <div className="bg-gradient-to-r from-primary to-orange-600 rounded-lg p-4 text-white">
      <h3 className="font-semibold mb-2">Portfolio Value</h3>
      <div className="space-y-1">
        <div className="text-2xl font-bold" data-testid="portfolio-total-value">
          ₹{totalValue.toLocaleString('en-IN')}
        </div>
        <div className="flex items-center justify-between text-sm">
          <span>Today's P&L</span>
          <span className="font-medium" data-testid="portfolio-today-pnl">
            {todayPnL >= 0 ? '+' : ''}₹{todayPnL.toLocaleString('en-IN')} ({todayPnLPercent.toFixed(2)}%)
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span>Total P&L</span>
          <span className="font-medium" data-testid="portfolio-total-pnl">
            {totalPnL >= 0 ? '+' : ''}₹{totalPnL.toLocaleString('en-IN')} ({totalPnLPercent.toFixed(2)}%)
          </span>
        </div>
      </div>
    </div>
  );
}
