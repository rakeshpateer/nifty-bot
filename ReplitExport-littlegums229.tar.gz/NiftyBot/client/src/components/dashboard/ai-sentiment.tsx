import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Progress } from '@/components/ui/progress';
import { Brain } from 'lucide-react';

interface MarketSentiment {
  overall: string;
  bullishPercent: string;
  bearishPercent: string;
  newsAnalysis: string;
  sectorPerformance: string;
}

interface NewsItem {
  title: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: number;
  source: string;
}

interface SectorPerformance {
  name: string;
  change: number;
  stocks: string[];
}

export function AISentiment() {
  const { data: sentiment, isLoading } = useQuery<MarketSentiment>({
    queryKey: ['/api/sentiment'],
    refetchInterval: 300000, // Update every 5 minutes
  });

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg border border-border p-6 animate-pulse">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Brain className="text-primary mr-2" />
            <div className="h-5 bg-muted rounded w-32"></div>
          </div>
          <div className="h-3 bg-muted rounded w-24"></div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="h-4 bg-muted rounded w-24"></div>
            <div className="h-4 bg-muted rounded w-32"></div>
          </div>
          <div className="h-2 bg-muted rounded w-full"></div>
          <div className="space-y-2">
            <div className="h-4 bg-muted rounded w-20"></div>
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-muted rounded-full mt-2"></div>
                <div className="h-3 bg-muted rounded flex-1"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!sentiment) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center">
            <Brain className="text-primary mr-2" />
            AI Market Sentiment
          </h3>
        </div>
        <div className="text-center py-4 text-muted-foreground">
          <p>Sentiment analysis unavailable</p>
        </div>
      </div>
    );
  }

  const overall = parseFloat(sentiment.overall);
  const bullishPercent = parseFloat(sentiment.bullishPercent);
  
  let newsAnalysis: NewsItem[] = [];
  let sectorPerformance: SectorPerformance[] = [];
  
  try {
    newsAnalysis = JSON.parse(sentiment.newsAnalysis);
    sectorPerformance = JSON.parse(sentiment.sectorPerformance);
  } catch (error) {
    console.error('Error parsing sentiment data:', error);
  }

  const getSentimentLabel = (score: number) => {
    if (score >= 70) return { label: 'Very Bullish', color: 'text-secondary' };
    if (score >= 55) return { label: 'Bullish', color: 'text-secondary' };
    if (score >= 45) return { label: 'Neutral', color: 'text-muted-foreground' };
    if (score >= 30) return { label: 'Bearish', color: 'text-destructive' };
    return { label: 'Very Bearish', color: 'text-destructive' };
  };

  const sentimentInfo = getSentimentLabel(overall);

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center">
          <Brain className="text-primary mr-2" />
          AI Market Sentiment
        </h3>
        <span className="text-xs text-muted-foreground">Updated 5 min ago</span>
      </div>
      
      <div className="space-y-4">
        {/* Sentiment Score */}
        <div className="flex items-center justify-between">
          <span className="text-sm">Market Sentiment</span>
          <div className="flex items-center space-x-2">
            <Progress value={bullishPercent} className="w-20 h-2" />
            <span className={`text-sm font-medium ${sentimentInfo.color}`}>
              {sentimentInfo.label} ({overall.toFixed(0)}%)
            </span>
          </div>
        </div>

        {/* News Analysis */}
        {newsAnalysis.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">News Analysis</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              {newsAnalysis.slice(0, 3).map((news, index) => {
                const getSentimentDot = (sentiment: string) => {
                  switch (sentiment) {
                    case 'positive': return 'bg-secondary';
                    case 'negative': return 'bg-destructive';
                    default: return 'bg-accent';
                  }
                };
                
                return (
                  <div key={index} className="flex items-start space-x-2">
                    <div className={`w-2 h-2 ${getSentimentDot(news.sentiment)} rounded-full mt-2 flex-shrink-0`}></div>
                    <span className="text-xs leading-relaxed">{news.title}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Sector Performance */}
        {sectorPerformance.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Top Performing Sectors</h4>
            <div className="space-y-1">
              {sectorPerformance.slice(0, 3).map((sector, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="truncate max-w-32">{sector.name}</span>
                  <span className={sector.change >= 0 ? 'text-secondary' : 'text-destructive'}>
                    {sector.change >= 0 ? '+' : ''}{sector.change.toFixed(2)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
