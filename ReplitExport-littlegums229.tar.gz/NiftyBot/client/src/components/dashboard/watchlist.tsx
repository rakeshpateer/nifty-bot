import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Plus, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';

interface WatchlistItem {
  id: string;
  stockId: string;
  stock: {
    id: string;
    symbol: string;
    name: string;
  };
  latestPrice?: {
    price: string;
    changePercent: string;
  };
}

export function Watchlist() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: watchlist, isLoading } = useQuery<WatchlistItem[]>({
    queryKey: ['/api/watchlist'],
    enabled: !!user,
  });

  const removeMutation = useMutation({
    mutationFn: async (stockId: string) => {
      await apiRequest('DELETE', `/api/watchlist/${stockId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/watchlist'] });
      toast({
        title: "Success",
        description: "Stock removed from watchlist",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to remove stock from watchlist",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold">Watchlist</h3>
          <span className="text-xs text-muted-foreground">Loading...</span>
        </div>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse p-3 bg-muted rounded-md">
              <div className="flex items-center justify-between">
                <div>
                  <div className="h-4 bg-muted-foreground/20 rounded w-16 mb-1"></div>
                  <div className="h-3 bg-muted-foreground/20 rounded w-24"></div>
                </div>
                <div className="text-right">
                  <div className="h-4 bg-muted-foreground/20 rounded w-20 mb-1"></div>
                  <div className="h-3 bg-muted-foreground/20 rounded w-12"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!watchlist || watchlist.length === 0) {
    return (
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold">Watchlist</h3>
          <Button size="sm" variant="secondary" data-testid="button-add-watchlist">
            <Plus className="w-4 h-4 mr-1" />
            Add Stock
          </Button>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          <p>Your watchlist is empty</p>
          <p className="text-xs mt-1">Add stocks to track their prices</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold">Watchlist</h3>
        <span className="text-xs text-muted-foreground">Live Prices</span>
      </div>
      
      <div className="space-y-2">
        {watchlist.map((item) => {
          const price = item.latestPrice?.price ? parseFloat(item.latestPrice.price) : 0;
          const changePercent = item.latestPrice?.changePercent ? parseFloat(item.latestPrice.changePercent) : 0;
          const isPositive = changePercent >= 0;
          
          return (
            <div 
              key={item.id} 
              className="flex items-center justify-between p-3 bg-muted rounded-md hover:bg-muted/80 transition-colors group"
              data-testid={`watchlist-item-${item.stock.symbol}`}
            >
              <div>
                <div className="font-medium text-sm">{item.stock.symbol.replace('.NS', '')}</div>
                <div className="text-xs text-muted-foreground truncate max-w-32">
                  {item.stock.name}
                </div>
              </div>
              <div className="text-right flex items-center space-x-2">
                <div>
                  <div className="font-mono text-sm" data-testid={`price-${item.stock.symbol}`}>
                    {price > 0 ? `₹${price.toFixed(2)}` : '--'}
                  </div>
                  <div 
                    className={`text-xs ${isPositive ? 'text-secondary' : 'text-destructive'}`}
                    data-testid={`change-${item.stock.symbol}`}
                  >
                    {price > 0 ? `${isPositive ? '+' : ''}${changePercent.toFixed(2)}%` : '--'}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 h-6 w-6"
                  onClick={() => removeMutation.mutate(item.stockId)}
                  disabled={removeMutation.isPending}
                  data-testid={`button-remove-${item.stock.symbol}`}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
      
      <Button 
        variant="ghost" 
        size="sm" 
        className="w-full mt-3 text-xs text-accent hover:text-accent/80 transition-colors"
        data-testid="button-view-all-stocks"
      >
        View All Stocks →
      </Button>
    </div>
  );
}
