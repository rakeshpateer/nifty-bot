import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';

interface TradingSignal {
  id: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: string;
  targetPrice: string;
  stopLoss: string;
  stock: {
    symbol: string;
    name: string;
  };
}

export function TradingSignals() {
  const { data: signals, isLoading } = useQuery<TradingSignal[]>({
    queryKey: ['/api/signals'],
    refetchInterval: 60000, // Update every minute
  });

  if (isLoading) {
    return (
      <div>
        <h3 className="font-semibold mb-3">Latest Signals</h3>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="p-3 border border-muted rounded-md animate-pulse">
              <div className="flex items-center justify-between mb-1">
                <div className="h-4 bg-muted rounded w-20"></div>
                <div className="h-6 bg-muted rounded w-12"></div>
              </div>
              <div className="h-3 bg-muted rounded w-32 mb-1"></div>
              <div className="h-3 bg-muted rounded w-24"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!signals || signals.length === 0) {
    return (
      <div>
        <h3 className="font-semibold mb-3">Latest Signals</h3>
        <div className="text-center py-8 text-muted-foreground">
          <p>No trading signals available</p>
          <p className="text-xs mt-1">AI analysis is generating new signals</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h3 className="font-semibold mb-3">Latest Signals</h3>
      <div className="space-y-2">
        {signals.slice(0, 3).map((signal) => {
          const targetPrice = parseFloat(signal.targetPrice);
          const stopLoss = parseFloat(signal.stopLoss);
          const confidence = parseFloat(signal.confidence);
          
          const getSignalVariant = (type: string) => {
            switch (type) {
              case 'BUY': return 'secondary';
              case 'SELL': return 'destructive';
              default: return 'default';
            }
          };
          
          const getSignalBorderColor = (type: string) => {
            switch (type) {
              case 'BUY': return 'border-secondary/20 bg-secondary/5';
              case 'SELL': return 'border-destructive/20 bg-destructive/5';
              default: return 'border-accent/20 bg-accent/5';
            }
          };
          
          return (
            <div 
              key={signal.id} 
              className={`p-3 border rounded-md ${getSignalBorderColor(signal.type)}`}
              data-testid={`signal-${signal.stock.symbol}`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">
                  {signal.stock.symbol.replace('.NS', '')}
                </span>
                <Badge variant={getSignalVariant(signal.type) as any} className="text-xs">
                  {signal.type}
                </Badge>
              </div>
              <div className="text-xs text-muted-foreground">
                Target: ₹{targetPrice.toFixed(2)} | SL: ₹{stopLoss.toFixed(2)}
              </div>
              <div className="text-xs text-muted-foreground">
                Confidence: {confidence.toFixed(0)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
