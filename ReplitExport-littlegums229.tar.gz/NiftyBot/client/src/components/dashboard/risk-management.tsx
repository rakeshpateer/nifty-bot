import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Shield } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface RiskMetrics {
  beta: number;
  maxDrawdown: number;
  sharpeRatio: number;
  volatility: number;
}

export function RiskManagement() {
  const { user } = useAuth();
  const [riskPerTrade, setRiskPerTrade] = useState(2);
  const [stopLoss, setStopLoss] = useState(5);
  
  const { data: riskMetrics, isLoading } = useQuery<RiskMetrics>({
    queryKey: ['/api/risk', user?.id],
    enabled: !!user?.id,
  });

  // Mock portfolio value for calculation
  const portfolioValue = 1245892; // This would come from portfolio data
  
  const calculatePositionSize = (riskPercent: number, stopLossPercent: number) => {
    const riskAmount = (portfolioValue * riskPercent) / 100;
    const positionSize = riskAmount / (stopLossPercent / 100);
    return {
      positionSize: Math.floor(positionSize),
      riskAmount: Math.floor(riskAmount),
      maxShares: Math.floor(positionSize / 2847.50) // Using RELIANCE price as example
    };
  };

  const positionCalc = calculatePositionSize(riskPerTrade, stopLoss);

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg border border-border p-6 animate-pulse">
        <div className="flex items-center mb-4">
          <Shield className="text-accent mr-2" />
          <div className="h-5 bg-muted rounded w-32"></div>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {[1, 2].map((i) => (
              <div key={i} className="bg-muted rounded-md p-3">
                <div className="h-3 bg-muted-foreground/20 rounded w-20 mb-1"></div>
                <div className="h-6 bg-muted-foreground/20 rounded w-16 mb-1"></div>
                <div className="h-3 bg-muted-foreground/20 rounded w-16"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getRiskLabel = (beta: number) => {
    if (beta < 0.8) return { label: 'Low Risk', color: 'text-secondary' };
    if (beta < 1.2) return { label: 'Moderate Risk', color: 'text-accent' };
    return { label: 'High Risk', color: 'text-destructive' };
  };

  const betaInfo = riskMetrics ? getRiskLabel(riskMetrics.beta) : { label: 'Unknown', color: 'text-muted-foreground' };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h3 className="font-semibold flex items-center mb-4">
        <Shield className="text-accent mr-2" />
        Risk Management
      </h3>
      
      <div className="space-y-4">
        {/* Portfolio Risk Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted rounded-md p-3">
            <div className="text-xs text-muted-foreground mb-1">Portfolio Beta</div>
            <div className="font-mono text-lg font-semibold" data-testid="portfolio-beta">
              {riskMetrics?.beta.toFixed(2) || '1.00'}
            </div>
            <div className={`text-xs ${betaInfo.color}`}>{betaInfo.label}</div>
          </div>
          <div className="bg-muted rounded-md p-3">
            <div className="text-xs text-muted-foreground mb-1">Max Drawdown</div>
            <div className="font-mono text-lg font-semibold text-destructive" data-testid="max-drawdown">
              -{riskMetrics?.maxDrawdown.toFixed(1) || '0.0'}%
            </div>
            <div className="text-xs text-muted-foreground">Last 30 days</div>
          </div>
        </div>

        {/* Position Sizing Calculator */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Position Sizing</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="risk-per-trade" className="text-xs text-muted-foreground">Risk per Trade</Label>
              <Input
                id="risk-per-trade"
                type="number"
                value={riskPerTrade}
                onChange={(e) => setRiskPerTrade(Number(e.target.value))}
                className="text-sm"
                data-testid="input-risk-per-trade"
              />
              <span className="text-xs text-muted-foreground">% of portfolio</span>
            </div>
            <div>
              <Label htmlFor="stop-loss" className="text-xs text-muted-foreground">Stop Loss</Label>
              <Input
                id="stop-loss"
                type="number"
                value={stopLoss}
                onChange={(e) => setStopLoss(Number(e.target.value))}
                className="text-sm"
                data-testid="input-stop-loss"
              />
              <span className="text-xs text-muted-foreground">% below entry</span>
            </div>
          </div>
          <Card className="bg-accent/10 border-accent/20">
            <CardContent className="p-3">
              <div className="text-sm">
                <span className="text-muted-foreground">Suggested position size:</span>
                <span className="font-mono font-medium ml-2" data-testid="suggested-position-size">
                  ₹{positionCalc.positionSize.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Max shares: <span data-testid="max-shares">{positionCalc.maxShares}</span> | 
                Risk amount: <span data-testid="risk-amount">₹{positionCalc.riskAmount.toLocaleString('en-IN')}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Daily Loss Limit */}
        <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded-md p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-orange-800 dark:text-orange-200">Daily Loss Limit</span>
            <span className="text-sm text-orange-700 dark:text-orange-300" data-testid="daily-loss-usage">
              ₹1,250 / ₹5,000
            </span>
          </div>
          <div className="w-full bg-orange-200 dark:bg-orange-800 rounded-full h-2 mt-2">
            <div className="bg-orange-500 h-2 rounded-full w-1/4" data-testid="daily-loss-progress"></div>
          </div>
          <div className="text-xs text-orange-600 dark:text-orange-400 mt-1">25% of daily limit used</div>
        </div>
      </div>
    </div>
  );
}
