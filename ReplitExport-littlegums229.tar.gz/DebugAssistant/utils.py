import pandas as pd
import numpy as np
from datetime import time

class SessionFilter:
    """Handle session filtering for NY RTH"""
    
    def __init__(self):
        self.ny_open = time(9, 30)
        self.ny_close = time(16, 0)
    
    def apply_ny_session_filter(self, data):
        """Filter data for NY Regular Trading Hours (9:30-16:00)"""
        if data.empty:
            return data
            
        # Check if index has timezone info
        if hasattr(data.index, 'tz') and data.index.tz is not None:
            # Convert to US/Eastern timezone
            try:
                data.index = data.index.tz_convert('US/Eastern')
            except:
                pass
        
        # Filter by time
        mask = data.index.to_series().dt.time.between(self.ny_open, self.ny_close)
        return data[mask]

class PerformanceTracker:
    """Track and calculate performance metrics for strategies"""
    
    def __init__(self):
        pass
    
    def calculate_performance_metrics(self, data, signals):
        """Calculate performance metrics for all strategies"""
        all_signals = []
        
        # Combine all signals
        for strategy, signal_data in signals.items():
            if len(signal_data) > 0:
                signal_data['strategy'] = strategy
                all_signals.append(signal_data)
        
        if not all_signals:
            return {
                'win_rate': 0,
                'avg_return': 0,
                'max_drawdown': 0,
                'sharpe_ratio': 0
            }
        
        combined_signals = pd.concat(all_signals, ignore_index=True)
        
        # Calculate returns for each signal (simplified)
        returns = []
        
        for _, signal in combined_signals.iterrows():
            # Find the signal timestamp in data
            signal_time = signal['timestamp']
            
            try:
                signal_idx = data.index.get_loc(signal_time)
                
                # Look ahead 5 periods for return calculation
                if signal_idx + 5 < len(data):
                    entry_price = signal['price']
                    exit_price = data.iloc[signal_idx + 5]['Close']
                    
                    if signal['type'] == 'CALL':
                        ret = (exit_price - entry_price) / entry_price * 100
                    else:  # PUT
                        ret = (entry_price - exit_price) / entry_price * 100
                    
                    returns.append(ret)
            except:
                continue
        
        if not returns:
            return {
                'win_rate': 0,
                'avg_return': 0,
                'max_drawdown': 0,
                'sharpe_ratio': 0
            }
        
        returns = np.array(returns)
        
        # Calculate metrics
        win_rate = (returns > 0).sum() / len(returns) * 100
        avg_return = returns.mean()
        
        # Calculate maximum drawdown
        cumulative_returns = np.cumsum(returns)
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdown = cumulative_returns - running_max
        max_drawdown = abs(drawdown.min()) if len(drawdown) > 0 else 0
        
        # Calculate Sharpe ratio (simplified)
        sharpe_ratio = avg_return / returns.std() if returns.std() > 0 else 0
        
        return {
            'win_rate': win_rate,
            'avg_return': avg_return,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio
        }

class DataValidator:
    """Validate and clean market data"""
    
    def __init__(self):
        pass
    
    def validate_data(self, data):
        """Validate market data integrity"""
        if data.empty:
            return False, "Data is empty"
        
        required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        missing_columns = [col for col in required_columns if col not in data.columns]
        
        if missing_columns:
            return False, f"Missing columns: {missing_columns}"
        
        # Check for negative prices
        price_columns = ['Open', 'High', 'Low', 'Close']
        for col in price_columns:
            if (data[col] <= 0).any():
                return False, f"Negative or zero prices found in {col}"
        
        # Check for logical price relationships
        if (data['High'] < data['Low']).any():
            return False, "High prices lower than Low prices"
        
        if (data['High'] < data['Open']).any() or (data['High'] < data['Close']).any():
            return False, "High prices lower than Open/Close prices"
        
        if (data['Low'] > data['Open']).any() or (data['Low'] > data['Close']).any():
            return False, "Low prices higher than Open/Close prices"
        
        return True, "Data validation passed"
    
    def clean_data(self, data):
        """Clean and prepare market data"""
        # Remove any rows with NaN values
        data = data.dropna()
        
        # Ensure data is sorted by timestamp
        data = data.sort_index()
        
        # Remove duplicate timestamps
        data = data[~data.index.duplicated(keep='first')]
        
        return data
