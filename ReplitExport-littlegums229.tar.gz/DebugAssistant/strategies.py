import pandas as pd
import numpy as np
from datetime import datetime, time

class TradingStrategies:
    def __init__(self):
        pass
    
    def calculate_all_strategies(self, data, params, activation, filtro_volumen=False, volumen_min=1000000):
        """Calculate all trading strategies based on activation flags"""
        signals = {}
        
        # Apply volume filter if enabled
        if filtro_volumen:
            data = data[data['Volume'] >= volumen_min]
        
        if activation.get('e1', False):
            signals['e1'] = self.estrategia_1_primera_vela_roja(data, params['e1'])
        else:
            signals['e1'] = pd.DataFrame()
            
        if activation.get('e2', False):
            signals['e2'] = self.estrategia_2_ruptura_gap(data, params['e2'])
        else:
            signals['e2'] = pd.DataFrame()
            
        if activation.get('e3', False):
            signals['e3'] = self.estrategia_3_hanger_diario(data, params['e3'])
        else:
            signals['e3'] = pd.DataFrame()
            
        if activation.get('e4', False):
            signals['e4'] = self.estrategia_4_modelo_4_pasos(data, params['e4'])
        else:
            signals['e4'] = pd.DataFrame()
            
        if activation.get('e5', False):
            signals['e5'] = self.estrategia_5_caida_fuerte(data, params['e5'])
        else:
            signals['e5'] = pd.DataFrame()
            
        if activation.get('e6', False):
            signals['e6'] = self.estrategia_6_caida_normal(data, params['e6'])
        else:
            signals['e6'] = pd.DataFrame()
            
        if activation.get('e7', False):
            signals['e7'] = self.estrategia_7_gap_bajista_alza(data, params['e7'])
        else:
            signals['e7'] = pd.DataFrame()
            
        if activation.get('e8', False):
            signals['e8'] = self.estrategia_8_gap_alza(data, params['e8'])
        else:
            signals['e8'] = pd.DataFrame()
            
        if activation.get('e9', False):
            signals['e9'] = self.estrategia_9_piso_fuerte(data, params['e9'])
        else:
            signals['e9'] = pd.DataFrame()
            
        if activation.get('e10', False):
            signals['e10'] = self.estrategia_10_pm40(data, params['e10'])
        else:
            signals['e10'] = pd.DataFrame()
        
        return signals
    
    def estrategia_1_primera_vela_roja(self, data, params):
        """E1: Primera Vela Roja (PUT Strategy)"""
        signals = []
        
        for i in range(1, len(data)):
            current = data.iloc[i]
            previous = data.iloc[i-1]
            
            # Check if current candle is red
            is_red = current['Close'] < current['Open']
            
            if not is_red:
                continue
                
            # Check if it's the first candle of the day (if solo_primera is enabled)
            if params['solo_primera']:
                current_time = current.name.time() if hasattr(current.name, 'time') else None
                if current_time and not (time(9, 30) <= current_time <= time(10, 0)):
                    continue
            
            # Generate signal
            if params['todas_rojas'] or params['solo_primera']:
                signals.append({
                    'timestamp': current.name,
                    'price': current['Close'],
                    'type': 'PUT',
                    'strategy': 'E1',
                    'confidence': 0.7,
                    'description': 'Primera Vela Roja'
                })
        
        return pd.DataFrame(signals)
    
    def estrategia_2_ruptura_gap(self, data, params):
        """E2: Ruptura de Piso GAP (PUT Strategy)"""
        signals = []
        
        for i in range(1, len(data)):
            current = data.iloc[i]
            previous = data.iloc[i-1]
            
            # Calculate GAP
            gap_percentage = ((current['Open'] - previous['Close']) / previous['Close']) * 100
            
            # Check for downward GAP
            if gap_percentage < -params['gap_min']:
                # Check if price breaks below GAP floor
                gap_floor = min(current['Open'], previous['Close'])
                
                if current['Low'] < gap_floor:
                    if params['confirmar_ruptura']:
                        # Confirm with close below GAP floor
                        if current['Close'] < gap_floor:
                            signals.append({
                                'timestamp': current.name,
                                'price': current['Close'],
                                'type': 'PUT',
                                'strategy': 'E2',
                                'confidence': 0.8,
                                'description': f'Ruptura GAP {gap_percentage:.2f}%'
                            })
                    else:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Low'],
                            'type': 'PUT',
                            'strategy': 'E2',
                            'confidence': 0.75,
                            'description': f'Ruptura GAP {gap_percentage:.2f}%'
                        })
        
        return pd.DataFrame(signals)
    
    def estrategia_3_hanger_diario(self, data, params):
        """E3: Hanger en Diario (PUT Strategy)"""
        signals = []
        
        for i in range(params['tendencia_alcista'], len(data)):
            current = data.iloc[i]
            
            # Calculate candle body and shadows
            body_size = abs(current['Close'] - current['Open'])
            total_range = current['High'] - current['Low']
            lower_shadow = min(current['Open'], current['Close']) - current['Low']
            
            if total_range == 0:
                continue
                
            body_percentage = (body_size / total_range) * 100
            lower_shadow_percentage = (lower_shadow / total_range) * 100
            
            # Check for hanger pattern
            is_hanger = (
                body_percentage <= params['cuerpo_max'] and
                lower_shadow_percentage >= params['mecha_inf_min']
            )
            
            if is_hanger:
                # Check for previous bullish trend
                prev_bars = data.iloc[i-params['tendencia_alcista']:i]
                bullish_days = sum(1 for j in range(len(prev_bars)) if prev_bars.iloc[j]['Close'] > prev_bars.iloc[j]['Open'])
                
                if bullish_days >= params['tendencia_alcista'] * 0.7:  # At least 70% bullish days
                    confidence = 0.8
                    
                    if params['confirmar'] and i + 1 < len(data):
                        next_candle = data.iloc[i + 1]
                        if next_candle['Close'] < current['Close']:
                            confidence = 0.9
                        else:
                            continue
                    
                    signals.append({
                        'timestamp': current.name,
                        'price': current['Close'],
                        'type': 'PUT',
                        'strategy': 'E3',
                        'confidence': confidence,
                        'description': 'Hanger en Diario'
                    })
        
        return pd.DataFrame(signals)
    
    def estrategia_4_modelo_4_pasos(self, data, params):
        """E4: Modelo 4 Pasos (PUT Strategy)"""
        signals = []
        
        for i in range(params['context_bars'], len(data)):
            current = data.iloc[i]
            
            # Step 1: Bearish context
            context_bars = data.iloc[i-params['context_bars']:i]
            bearish_bars = sum(1 for j in range(len(context_bars)) if context_bars.iloc[j]['Close'] < context_bars.iloc[j]['Open'])
            
            if bearish_bars < params['context_bars'] * 0.6:  # At least 60% bearish
                continue
            
            # Step 2: Ceiling formation
            recent_high = context_bars['High'].max()
            ceiling_threshold = recent_high * (1 - params['techo_sensibilidad'] / 100)
            
            if current['High'] < ceiling_threshold:
                continue
            
            # Step 3: Trend line break (simplified)
            if i >= params['lt_lookback']:
                trend_bars = data.iloc[i-params['lt_lookback']:i]
                trend_slope = (trend_bars['High'].iloc[-1] - trend_bars['High'].iloc[0]) / len(trend_bars)
                
                if trend_slope > 0:  # Upward trend line
                    expected_high = trend_bars['High'].iloc[-1] + trend_slope
                    if current['Low'] < expected_high * 0.98:  # Break below trend line
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Close'],
                            'type': 'PUT',
                            'strategy': 'E4',
                            'confidence': 0.85,
                            'description': 'Modelo 4 Pasos'
                        })
        
        return pd.DataFrame(signals)
    
    def estrategia_5_caida_fuerte(self, data, params):
        """E5: CF - Caída Fuerte (CALL Strategy)"""
        signals = []
        
        for i in range(2, len(data)):
            current = data.iloc[i]      # Vela 0
            prev1 = data.iloc[i-1]      # Vela -1
            prev2 = data.iloc[i-2]      # Vela -2
            
            # Check strong bearish candles in previous 2 bars
            body1 = abs(prev1['Close'] - prev1['Open'])
            body2 = abs(prev2['Close'] - prev2['Open'])
            
            body1_pct = (body1 / prev1['Open']) * 100
            body2_pct = (body2 / prev2['Open']) * 100
            
            strong_bearish1 = prev1['Close'] < prev1['Open'] and body1_pct >= params['cuerpo_min']
            strong_bearish2 = prev2['Close'] < prev2['Open'] and body2_pct >= params['cuerpo_min']
            
            if not (strong_bearish1 and strong_bearish2):
                continue
            
            # Check recovery in current candle
            recovery_from_low = ((current['Close'] - current['Low']) / (current['High'] - current['Low'])) * 100
            
            if recovery_from_low >= params['recuperacion_min']:
                # Check if it's first candle of day (if not permitted, skip)
                is_first_candle = False
                if hasattr(current.name, 'time'):
                    current_time = current.name.time()
                    is_first_candle = time(9, 30) <= current_time <= time(10, 0)
                
                if is_first_candle and not params['permitir_primera']:
                    continue
                
                signals.append({
                    'timestamp': current.name,
                    'price': current['Close'],
                    'type': 'CALL',
                    'strategy': 'E5',
                    'confidence': 0.8,
                    'description': 'Caída Fuerte - Recuperación'
                })
        
        return pd.DataFrame(signals)
    
    def estrategia_6_caida_normal(self, data, params):
        """E6: CN - Caída Normal (CALL Strategy)"""
        signals = []
        
        for i in range(5, len(data)):
            current = data.iloc[i]
            
            # Look for normal decline pattern
            recent_bars = data.iloc[i-5:i]
            max_decline = 0
            
            for j in range(len(recent_bars)):
                if j > 0:
                    decline = ((recent_bars.iloc[j-1]['Close'] - recent_bars.iloc[j]['Close']) / recent_bars.iloc[j-1]['Close']) * 100
                    max_decline = max(max_decline, decline)
            
            # Check if decline is within normal range
            if max_decline <= params['caida_max']:
                # Check proximity to support (simplified as recent low)
                recent_low = recent_bars['Low'].min()
                proximity = abs(current['Low'] - recent_low) / recent_low * 100
                
                if proximity <= params['prox_soporte']:
                    # Check for reversal candle
                    body_size = abs(current['Close'] - current['Open'])
                    body_pct = (body_size / current['Open']) * 100
                    
                    is_bullish = current['Close'] > current['Open']
                    
                    if is_bullish and body_pct >= params['cuerpo_giro_min']:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Close'],
                            'type': 'CALL',
                            'strategy': 'E6',
                            'confidence': 0.75,
                            'description': 'Caída Normal - Giro'
                        })
        
        return pd.DataFrame(signals)
    
    def estrategia_7_gap_bajista_alza(self, data, params):
        """E7: GBA - GAP Bajista al Alza (CALL Strategy)"""
        signals = []
        
        for i in range(3, len(data)):
            current = data.iloc[i]
            previous = data.iloc[i-1]
            
            # Check for bearish GAP
            gap_percentage = ((current['Open'] - previous['Close']) / previous['Close']) * 100
            
            if gap_percentage < -params['gap_bajista_min']:
                if params['tres_verdes']:
                    # Check for 3 consecutive green candles after GAP
                    green_count = 0
                    for j in range(min(3, len(data) - i)):
                        candle = data.iloc[i + j]
                        if candle['Close'] > candle['Open']:
                            green_count += 1
                        else:
                            break
                    
                    if green_count >= 3:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Close'],
                            'type': 'CALL',
                            'strategy': 'E7',
                            'confidence': 0.85,
                            'description': f'GAP Bajista {gap_percentage:.2f}% + 3 Verdes'
                        })
                else:
                    # Just check for recovery after bearish GAP
                    if current['Close'] > current['Open']:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Close'],
                            'type': 'CALL',
                            'strategy': 'E7',
                            'confidence': 0.7,
                            'description': f'GAP Bajista {gap_percentage:.2f}%'
                        })
        
        return pd.DataFrame(signals)
    
    def estrategia_8_gap_alza(self, data, params):
        """E8: GA - GAP al Alza (CALL Strategy)"""
        signals = []
        
        for i in range(1, len(data)):
            current = data.iloc[i]
            previous = data.iloc[i-1]
            
            # Check for upward GAP
            gap_percentage = ((current['Open'] - previous['Close']) / previous['Close']) * 100
            
            if gap_percentage >= params['gap_alza_min']:
                if params['modo_pares']:
                    # Check for non-overlapping pairs (simplified implementation)
                    if i % 2 == 0:  # Even index for pairing
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Open'],
                            'type': 'CALL',
                            'strategy': 'E8',
                            'confidence': 0.8,
                            'description': f'GAP Alza {gap_percentage:.2f}% (Par)'
                        })
                else:
                    signals.append({
                        'timestamp': current.name,
                        'price': current['Open'],
                        'type': 'CALL',
                        'strategy': 'E8',
                        'confidence': 0.75,
                        'description': f'GAP Alza {gap_percentage:.2f}%'
                    })
        
        return pd.DataFrame(signals)
    
    def estrategia_9_piso_fuerte(self, data, params):
        """E9: PF - Piso Fuerte (CALL Strategy)"""
        signals = []
        
        for i in range(10, len(data)):
            current = data.iloc[i]
            
            # Check proximity to SMA 200 (strong floor)
            if 'SMA_200' in data.columns:
                sma200 = current['SMA_200']
                proximity = abs(current['Low'] - sma200) / sma200 * 100
                
                if proximity <= params['prox_pm200']:
                    if params['confirmar_verde']:
                        # Confirm with green candle
                        if current['Close'] > current['Open']:
                            signals.append({
                                'timestamp': current.name,
                                'price': current['Close'],
                                'type': 'CALL',
                                'strategy': 'E9',
                                'confidence': 0.85,
                                'description': f'Piso Fuerte PM200 ({proximity:.2f}%)'
                            })
                    else:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Low'],
                            'type': 'CALL',
                            'strategy': 'E9',
                            'confidence': 0.75,
                            'description': f'Piso Fuerte PM200 ({proximity:.2f}%)'
                        })
        
        return pd.DataFrame(signals)
    
    def estrategia_10_pm40(self, data, params):
        """E10: PM40 (CALL Strategy)"""
        signals = []
        
        for i in range(5, len(data)):
            current = data.iloc[i]
            
            # Check proximity to SMA 40
            if 'SMA_40' in data.columns:
                sma40 = current['SMA_40']
                proximity = abs(current['Low'] - sma40) / sma40 * 100
                
                if proximity <= params['prox_pm40']:
                    if params['confirmar_estabilizacion']:
                        # Check for price stabilization around SMA 40
                        recent_bars = data.iloc[i-3:i+1]
                        price_range = recent_bars['High'].max() - recent_bars['Low'].min()
                        avg_price = recent_bars['Close'].mean()
                        
                        if price_range / avg_price <= 0.02:  # Price range within 2%
                            signals.append({
                                'timestamp': current.name,
                                'price': current['Close'],
                                'type': 'CALL',
                                'strategy': 'E10',
                                'confidence': 0.8,
                                'description': f'PM40 Estabilización ({proximity:.2f}%)'
                            })
                    else:
                        signals.append({
                            'timestamp': current.name,
                            'price': current['Low'],
                            'type': 'CALL',
                            'strategy': 'E10',
                            'confidence': 0.7,
                            'description': f'PM40 ({proximity:.2f}%)'
                        })
        
        return pd.DataFrame(signals)
