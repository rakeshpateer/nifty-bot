# 10 Trading Strategies Dashboard

## Overview

This is a comprehensive trading dashboard built with Streamlit that implements 10 different trading strategies for stock market analysis. The application provides real-time technical analysis using various indicators and trading signals, with a focus on both PUT and CALL strategies. The system is designed to analyze stock market data using yfinance for data retrieval and plotly for interactive visualizations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for web-based dashboard interface
- **Visualization**: Plotly for interactive charts and technical analysis graphs
- **Layout**: Wide layout with expandable sidebar for configuration controls
- **UI Components**: Multi-column layouts, date inputs, selectboxes, and boolean toggles

### Data Processing Layer
- **Data Source**: yfinance library for real-time stock market data retrieval
- **Data Processing**: Pandas and NumPy for data manipulation and calculations
- **Technical Analysis**: Custom implementation of technical indicators including SMA, EMA, Bollinger Bands, RSI, and MACD

### Trading Strategy Engine
- **Strategy Implementation**: Modular approach with 10 distinct trading strategies split between PUT strategies (E1-E4) and CALL strategies (E5-E10)
- **Signal Generation**: Real-time signal calculation based on technical indicators and price patterns
- **Strategy Activation**: Configurable on/off switches for each individual strategy

### Core Components
- **TradingStrategies Class**: Implements all 10 trading strategies with customizable parameters
- **TechnicalIndicators Class**: Calculates various technical indicators required for strategy analysis
- **SessionFilter Class**: Handles New York Regular Trading Hours (9:30-16:00) filtering
- **PerformanceTracker Class**: Tracks and calculates performance metrics for strategy evaluation

### Data Flow Architecture
1. User selects stock symbol and timeframe parameters
2. Data is fetched from yfinance API
3. Technical indicators are calculated using the TechnicalIndicators class
4. Trading strategies are executed based on user-selected activations
5. Results are visualized through interactive Plotly charts
6. Performance metrics are calculated and displayed

### Strategy Categories
- **PUT Strategies**: E1 (Primera Vela Roja), E2 (Ruptura GAP), E3 (Hanger Diario), E4 (Modelo 4 Pasos)
- **CALL Strategies**: E5 (Caída Fuerte), E6 (Caída Normal), E7 (GAP Bajista al Alza), E8 (GAP al Alza), E9 (Piso Fuerte), E10 (PM40)

### Configuration Management
- **Timeframe Support**: Multiple timeframes from 1 minute to 1 day intervals
- **Date Range Selection**: Configurable start and end dates for analysis
- **Volume Filtering**: Optional volume-based filtering with minimum thresholds
- **Session Filtering**: NY RTH session filtering capability

## External Dependencies

### Data Providers
- **yfinance**: Primary data source for stock market data, providing OHLCV data and historical information

### Python Libraries
- **streamlit**: Web application framework for dashboard interface
- **pandas**: Data manipulation and analysis library
- **numpy**: Numerical computing library for mathematical operations
- **plotly**: Interactive visualization library for charts and graphs
- **datetime**: Date and time handling for session filtering and date range selection

### Technical Analysis
- **Custom Indicators**: Self-implemented technical indicators rather than relying on external TA libraries
- **Real-time Processing**: Live data processing without external caching systems
- **No Database Dependencies**: Application operates without persistent data storage, processing data in memory

### Trading Market Integration
- **Market Data**: Real-time and historical stock data through yfinance
- **Session Awareness**: New York Stock Exchange Regular Trading Hours integration
- **Multi-Asset Support**: Compatible with various stock symbols and ETFs