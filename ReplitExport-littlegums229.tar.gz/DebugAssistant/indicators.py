import pandas as pd
import numpy as np

class TechnicalIndicators:
    """Calculate technical indicators for trading strategies"""
    
    def __init__(self):
        pass
    
    def calculate_all_indicators(self, data):
        """Calculate all required technical indicators"""
        data = data.copy()
        
        # Simple Moving Averages
        data['SMA_40'] = self.sma(data['Close'], 40)
        data['SMA_200'] = self.sma(data['Close'], 200)
        
        # Exponential Moving Averages
        data['EMA_20'] = self.ema(data['Close'], 20)
        data['EMA_50'] = self.ema(data['Close'], 50)
        
        # Bollinger Bands
        bb_upper, bb_middle, bb_lower = self.bollinger_bands(data['Close'], 20, 2)
        data['BB_Upper'] = bb_upper
        data['BB_Middle'] = bb_middle
        data['BB_Lower'] = bb_lower
        
        # RSI
        data['RSI'] = self.rsi(data['Close'], 14)
        
        # MACD
        macd, macd_signal, macd_histogram = self.macd(data['Close'])
        data['MACD'] = macd
        data['MACD_Signal'] = macd_signal
        data['MACD_Histogram'] = macd_histogram
        
        # Volume indicators
        data['Volume_SMA'] = self.sma(data['Volume'], 20)
        
        # Price change indicators
        data['Price_Change'] = data['Close'].pct_change() * 100
        data['High_Low_Range'] = ((data['High'] - data['Low']) / data['Low']) * 100
        
        # Support and Resistance levels
        data['Support'] = self.calculate_support_resistance(data, 'support')
        data['Resistance'] = self.calculate_support_resistance(data, 'resistance')
        
        return data
    
    def sma(self, series, period):
        """Simple Moving Average"""
        return series.rolling(window=period).mean()
    
    def ema(self, series, period):
        """Exponential Moving Average"""
        return series.ewm(span=period).mean()
    
    def bollinger_bands(self, series, period, std_dev):
        """Bollinger Bands"""
        sma = self.sma(series, period)
        std = series.rolling(window=period).std()
        
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        
        return upper, sma, lower
    
    def rsi(self, series, period):
        """Relative Strength Index"""
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def macd(self, series, fast=12, slow=26, signal=9):
        """MACD (Moving Average Convergence Divergence)"""
        ema_fast = self.ema(series, fast)
        ema_slow = self.ema(series, slow)
        
        macd_line = ema_fast - ema_slow
        signal_line = self.ema(macd_line, signal)
        histogram = macd_line - signal_line
        
        return macd_line, signal_line, histogram
    
    def calculate_support_resistance(self, data, level_type, lookback=20):
        """Calculate support and resistance levels"""
        if level_type == 'support':
            # Support is recent low
            return data['Low'].rolling(window=lookback).min()
        else:
            # Resistance is recent high
            return data['High'].rolling(window=lookback).max()
    
    def atr(self, data, period=14):
        """Average True Range"""
        high_low = data['High'] - data['Low']
        high_close_prev = abs(data['High'] - data['Close'].shift(1))
        low_close_prev = abs(data['Low'] - data['Close'].shift(1))
        
        true_range = pd.concat([high_low, high_close_prev, low_close_prev], axis=1).max(axis=1)
        atr = true_range.rolling(window=period).mean()
        
        return atr
    
    def stochastic(self, data, k_period=14, d_period=3):
        """Stochastic Oscillator"""
        lowest_low = data['Low'].rolling(window=k_period).min()
        highest_high = data['High'].rolling(window=k_period).max()
        
        k_percent = 100 * ((data['Close'] - lowest_low) / (highest_high - lowest_low))
        d_percent = k_percent.rolling(window=d_period).mean()
        
        return k_percent, d_percent
    
    def williams_r(self, data, period=14):
        """Williams %R"""
        highest_high = data['High'].rolling(window=period).max()
        lowest_low = data['Low'].rolling(window=period).min()
        
        williams_r = -100 * ((highest_high - data['Close']) / (highest_high - lowest_low))
        
        return williams_r
    
    def commodity_channel_index(self, data, period=20):
        """Commodity Channel Index (CCI)"""
        typical_price = (data['High'] + data['Low'] + data['Close']) / 3
        sma_tp = typical_price.rolling(window=period).mean()
        mean_deviation = typical_price.rolling(window=period).apply(
            lambda x: pd.Series(x).mad()
        )
        
        cci = (typical_price - sma_tp) / (0.015 * mean_deviation)
        
        return cci
    
    def money_flow_index(self, data, period=14):
        """Money Flow Index"""
        typical_price = (data['High'] + data['Low'] + data['Close']) / 3
        raw_money_flow = typical_price * data['Volume']
        
        # Positive and negative money flow
        positive_flow = raw_money_flow.where(typical_price > typical_price.shift(1), 0)
        negative_flow = raw_money_flow.where(typical_price < typical_price.shift(1), 0)
        
        positive_mf = positive_flow.rolling(window=period).sum()
        negative_mf = negative_flow.rolling(window=period).sum()
        
        money_ratio = positive_mf / negative_mf
        mfi = 100 - (100 / (1 + money_ratio))
        
        return mfi
    
    def on_balance_volume(self, data):
        """On Balance Volume"""
        obv = pd.Series(index=data.index, dtype=float)
        obv.iloc[0] = data['Volume'].iloc[0]
        
        for i in range(1, len(data)):
            if data['Close'].iloc[i] > data['Close'].iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] + data['Volume'].iloc[i]
            elif data['Close'].iloc[i] < data['Close'].iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] - data['Volume'].iloc[i]
            else:
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv
