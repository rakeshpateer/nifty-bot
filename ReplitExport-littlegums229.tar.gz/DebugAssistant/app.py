import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import datetime as dt
from strategies import TradingStrategies
from utils import SessionFilter, PerformanceTracker
from indicators import TechnicalIndicators
import warnings
warnings.filterwarnings('ignore')

# Page configuration
st.set_page_config(
    page_title="🟩 10 Trading Strategies Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Title
st.title("🟩 10 Estrategias Completas de Plata AG")
st.markdown("### Comprehensive Trading Strategy Dashboard")

# Sidebar configuration
st.sidebar.header("🎯 Configuración General")

# Symbol input with validation
symbol = st.sidebar.text_input("Stock Symbol", value="SPY", help="Enter stock symbol (e.g., SPY, AAPL)")

# Valid symbol validation
valid_symbols = ['SPY', 'AAPL', 'GOOGL', 'MSFT', 'TSLA', 'AMZN', 'META', 'NVDA', 'QQQ', 'IWM']
if symbol and symbol.upper() not in [s.upper() for s in valid_symbols] and len(symbol.strip()) > 0:
    st.sidebar.warning(f"Symbol {symbol} might not be valid. Try: {', '.join(valid_symbols[:5])}")
    
# Clean symbol
symbol = symbol.upper().strip() if symbol else "SPY"

# Timeframe selection
timeframes = {
    "1m": "1 minute",
    "5m": "5 minutes", 
    "15m": "15 minutes",
    "30m": "30 minutes",
    "1h": "1 hour",
    "1d": "1 day"
}
timeframe = st.sidebar.selectbox("Marco Temporal", options=list(timeframes.keys()), 
                                index=3, format_func=lambda x: timeframes[x])

# Date range
col1, col2 = st.sidebar.columns(2)
with col1:
    start_date = st.date_input("Start Date", value=dt.date.today() - dt.timedelta(days=30))
with col2:
    end_date = st.date_input("End Date", value=dt.date.today())

# Session filter
usar_sesion_ny = st.sidebar.checkbox("Usar Sesión NY RTH (9:30-16:00)", value=True)
mostrar_debug = st.sidebar.checkbox("Mostrar Tabla de Debug", value=False)

# Strategy activation
st.sidebar.header("📊 Activación de Estrategias")

# PUT Strategies
st.sidebar.subheader("🟥 PUT Strategies")
activar_E1 = st.sidebar.checkbox("E1: 1ª Vela Roja", value=True)
activar_E2 = st.sidebar.checkbox("E2: Ruptura de Piso GAP", value=True)
activar_E3 = st.sidebar.checkbox("E3: Hanger en Diario", value=True)
activar_E4 = st.sidebar.checkbox("E4: Modelo 4 Pasos", value=True)

# CALL Strategies
st.sidebar.subheader("🟩 CALL Strategies")
activar_E5 = st.sidebar.checkbox("E5: CF - Caída Fuerte", value=True)
activar_E6 = st.sidebar.checkbox("E6: CN - Caída Normal", value=True)
activar_E7 = st.sidebar.checkbox("E7: GBA - GAP Bajista al Alza", value=True)
activar_E8 = st.sidebar.checkbox("E8: GA - GAP al Alza", value=True)
activar_E9 = st.sidebar.checkbox("E9: PF - Piso Fuerte", value=True)
activar_E10 = st.sidebar.checkbox("E10: PM40", value=True)

# Strategy parameters in expanders
with st.sidebar.expander("🟥 E1: 1ª Vela Roja - Parameters"):
    e1_solo_primera = st.checkbox("Solo primera vela del día (9:30-10:00)", value=False, key="e1_solo")
    e1_todas_rojas = st.checkbox("Todas las velas rojas válidas", value=True, key="e1_todas")

with st.sidebar.expander("🟥 E2: Ruptura GAP - Parameters"):
    e2_gap_min = st.slider("GAP mínimo (%)", 0.1, 2.0, 0.5, 0.1, key="e2_gap")
    e2_confirmar_ruptura = st.checkbox("Confirmar ruptura del piso", value=True, key="e2_confirm")

with st.sidebar.expander("🟥 E3: Hanger Diario - Parameters"):
    e3_cuerpo_max = st.slider("Cuerpo máximo (% del rango)", 10.0, 50.0, 30.0, 5.0, key="e3_cuerpo")
    e3_mecha_inf_min = st.slider("Mecha inferior mínima (% del rango)", 40.0, 80.0, 60.0, 5.0, key="e3_mecha")
    e3_confirmar = st.checkbox("Confirmar día siguiente", value=False, key="e3_confirm")
    e3_tendencia_alcista = st.slider("Días alcistas previos", 3, 10, 5, key="e3_dias")

with st.sidebar.expander("🟥 E4: Modelo 4 Pasos - Parameters"):
    e4_context_bars = st.slider("Barras para contexto bajista", 5, 20, 10, key="e4_context")
    e4_techo_sensibilidad = st.slider("Sensibilidad techo (%)", 0.5, 5.0, 2.0, 0.5, key="e4_techo")
    e4_lt_lookback = st.slider("Lookback para línea tendencia", 3, 10, 5, key="e4_lookback")

with st.sidebar.expander("🟩 E5: Caída Fuerte - Parameters"):
    e5_cuerpo_min = st.slider("Cuerpo mínimo velas -2,-1 (%)", 0.5, 3.0, 1.0, 0.1, key="e5_cuerpo")
    e5_recuperacion_min = st.slider("Recuperación mínima vela 0 (%)", 30.0, 80.0, 50.0, 5.0, key="e5_recup")
    e5_permitir_primera = st.checkbox("Permitir primera vela del día", value=True, key="e5_primera")

with st.sidebar.expander("🟩 E6: Caída Normal - Parameters"):
    e6_caida_max = st.slider("Caída máxima por vela (%)", 1.0, 5.0, 3.0, 0.5, key="e6_caida")
    e6_prox_soporte = st.slider("Proximidad a soporte (%)", 0.5, 2.0, 1.0, 0.1, key="e6_soporte")
    e6_cuerpo_giro_min = st.slider("Cuerpo mínimo vela giro (%)", 0.5, 2.0, 0.8, 0.1, key="e6_giro")

with st.sidebar.expander("🟩 E7: GAP Bajista al Alza - Parameters"):
    e7_gap_bajista_min = st.slider("GAP bajista mínimo (%)", 0.1, 1.0, 0.3, 0.1, key="e7_gap")
    e7_tres_verdes = st.checkbox("Requiere 3 velas verdes consecutivas", value=True, key="e7_verdes")

with st.sidebar.expander("🟩 E8: GAP al Alza - Parameters"):
    e8_gap_alza_min = st.slider("GAP al alza mínimo (%)", 0.2, 2.0, 0.5, 0.1, key="e8_gap")
    e8_modo_pares = st.checkbox("Modo pares no solapados", value=False, key="e8_pares")

with st.sidebar.expander("🟩 E9: Piso Fuerte - Parameters"):
    e9_prox_pm200 = st.slider("Proximidad PM200 (%)", 0.5, 3.0, 1.5, 0.1, key="e9_pm200")
    e9_confirmar_verde = st.checkbox("Confirmar con vela verde", value=True, key="e9_verde")

with st.sidebar.expander("🟩 E10: PM40 - Parameters"):
    e10_prox_pm40 = st.slider("Proximidad PM40 (%)", 0.3, 2.0, 1.0, 0.1, key="e10_pm40")
    e10_confirmar_estabilizacion = st.checkbox("Confirmar estabilización", value=True, key="e10_estab")

# Filters
with st.sidebar.expander("⚙️ Filtros Generales"):
    filtro_sesion = st.checkbox("Aplicar filtro de sesión", value=True)
    filtro_volumen = st.checkbox("Filtro de volumen mínimo", value=False)
    volumen_min = st.number_input("Volumen mínimo", value=1000000, min_value=100000, step=100000)

# Main content
try:
    # Load data with better error handling
    with st.spinner(f"Loading data for {symbol}..."):
        try:
            ticker = yf.Ticker(symbol)
            
            # Get different timeframe data
            if timeframe in ['1m', '5m', '15m', '30m']:
                period = "7d"  # Short period for intraday
            elif timeframe == '1h':
                period = "30d"
            else:
                period = "1y"
                
            data = ticker.history(period=period, interval=timeframe, start=start_date, end=end_date)
            
            if data.empty:
                st.error(f"❌ No data found for symbol {symbol}. Please check the symbol name.")
                st.info("💡 Try symbols like: SPY, AAPL, GOOGL, MSFT, TSLA")
                st.stop()
                
        except Exception as e:
            st.error(f"❌ Error loading data for {symbol}: {str(e)}")
            st.info("💡 This might be due to:")
            st.info("• Invalid symbol name")
            st.info("• Network connectivity issues") 
            st.info("• Yahoo Finance API temporary issues")
            st.stop()

    # Initialize components
    session_filter = SessionFilter()
    technical_indicators = TechnicalIndicators()
    strategies = TradingStrategies()
    performance_tracker = PerformanceTracker()

    # Apply session filter if enabled
    if usar_sesion_ny and filtro_sesion:
        data = session_filter.apply_ny_session_filter(data)

    # Calculate technical indicators
    data = technical_indicators.calculate_all_indicators(data)

    # Prepare strategy parameters
    strategy_params = {
        'e1': {'solo_primera': e1_solo_primera, 'todas_rojas': e1_todas_rojas},
        'e2': {'gap_min': e2_gap_min, 'confirmar_ruptura': e2_confirmar_ruptura},
        'e3': {'cuerpo_max': e3_cuerpo_max, 'mecha_inf_min': e3_mecha_inf_min, 'confirmar': e3_confirmar, 'tendencia_alcista': e3_tendencia_alcista},
        'e4': {'context_bars': e4_context_bars, 'techo_sensibilidad': e4_techo_sensibilidad, 'lt_lookback': e4_lt_lookback},
        'e5': {'cuerpo_min': e5_cuerpo_min, 'recuperacion_min': e5_recuperacion_min, 'permitir_primera': e5_permitir_primera},
        'e6': {'caida_max': e6_caida_max, 'prox_soporte': e6_prox_soporte, 'cuerpo_giro_min': e6_cuerpo_giro_min},
        'e7': {'gap_bajista_min': e7_gap_bajista_min, 'tres_verdes': e7_tres_verdes},
        'e8': {'gap_alza_min': e8_gap_alza_min, 'modo_pares': e8_modo_pares},
        'e9': {'prox_pm200': e9_prox_pm200, 'confirmar_verde': e9_confirmar_verde},
        'e10': {'prox_pm40': e10_prox_pm40, 'confirmar_estabilizacion': e10_confirmar_estabilizacion}
    }

    # Strategy activation map
    strategy_activation = {
        'e1': activar_E1, 'e2': activar_E2, 'e3': activar_E3, 'e4': activar_E4,
        'e5': activar_E5, 'e6': activar_E6, 'e7': activar_E7, 'e8': activar_E8,
        'e9': activar_E9, 'e10': activar_E10
    }

    # Calculate strategy signals
    signals = strategies.calculate_all_strategies(data, strategy_params, strategy_activation, filtro_volumen, volumen_min)

    # Create main chart
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=[f'{symbol} - Candlestick Chart with Strategy Signals', 'Volume'],
        vertical_spacing=0.1,
        row_width=[0.7, 0.3]
    )

    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=data.index,
            open=data['Open'],
            high=data['High'],
            low=data['Low'],
            close=data['Close'],
            name=symbol
        ),
        row=1, col=1
    )

    # Add moving averages
    if 'SMA_40' in data.columns:
        fig.add_trace(
            go.Scatter(x=data.index, y=data['SMA_40'], mode='lines', name='SMA 40', line=dict(color='orange')),
            row=1, col=1
        )
    
    if 'SMA_200' in data.columns:
        fig.add_trace(
            go.Scatter(x=data.index, y=data['SMA_200'], mode='lines', name='SMA 200', line=dict(color='blue')),
            row=1, col=1
        )

    # Add strategy signals
    colors = {
        'PUT': 'red',
        'CALL': 'green'
    }

    for strategy, signal_data in signals.items():
        if len(signal_data) > 0:
            for _, signal in signal_data.iterrows():
                color = colors.get(signal['type'], 'gray')
                symbol_marker = '▼' if signal['type'] == 'PUT' else '▲'
                
                fig.add_trace(
                    go.Scatter(
                        x=[signal['timestamp']],
                        y=[signal['price']],
                        mode='markers+text',
                        name=f"{strategy.upper()} {signal['type']}",
                        marker=dict(color=color, size=15, symbol='triangle-down' if signal['type'] == 'PUT' else 'triangle-up'),
                        text=[symbol_marker],
                        textposition='middle center',
                        showlegend=True
                    ),
                    row=1, col=1
                )

    # Add volume chart
    fig.add_trace(
        go.Bar(x=data.index, y=data['Volume'], name='Volume', marker_color='lightblue'),
        row=2, col=1
    )

    # Update layout
    fig.update_layout(
        title=f'{symbol} Trading Dashboard - {timeframes[timeframe]}',
        xaxis_title='Time',
        yaxis_title='Price',
        height=800,
        showlegend=True,
        xaxis_rangeslider_visible=False
    )

    # Display chart
    st.plotly_chart(fig, use_container_width=True)

    # Strategy summary
    col1, col2, col3 = st.columns(3)
    
    total_signals = sum(len(signals[s]) for s in signals)
    put_signals = sum(len(signals[s]) for s in signals if any(signals[s]['type'] == 'PUT') if len(signals[s]) > 0)
    call_signals = sum(len(signals[s]) for s in signals if any(signals[s]['type'] == 'CALL') if len(signals[s]) > 0)

    with col1:
        st.metric("Total Signals", total_signals)
    with col2:
        st.metric("PUT Signals", put_signals)
    with col3:
        st.metric("CALL Signals", call_signals)

    # Strategy details
    st.subheader("📊 Strategy Signal Details")
    
    for strategy, signal_data in signals.items():
        if len(signal_data) > 0:
            with st.expander(f"{strategy.upper()} - {len(signal_data)} signals"):
                st.dataframe(signal_data, use_container_width=True)

    # Debug table
    if mostrar_debug:
        st.subheader("🔍 Debug Information")
        
        debug_data = {
            'Symbol': symbol,
            'Timeframe': timeframes[timeframe],
            'Data Points': len(data),
            'Date Range': f"{str(data.index[0])[:16]} to {str(data.index[-1])[:16]}",
            'NY Session Filter': usar_sesion_ny,
            'Volume Filter': filtro_volumen,
            'Active Strategies': sum(strategy_activation.values())
        }
        
        debug_items = [[k, str(v)] for k, v in debug_data.items()]
        debug_df = pd.DataFrame(debug_items, columns=['Parameter', 'Value'])
        st.table(debug_df)

    # Performance metrics
    if total_signals > 0:
        st.subheader("📈 Performance Summary")
        performance_metrics = performance_tracker.calculate_performance_metrics(data, signals)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Win Rate", f"{performance_metrics.get('win_rate', 0):.1f}%")
        with col2:
            st.metric("Avg Return", f"{performance_metrics.get('avg_return', 0):.2f}%")
        with col3:
            st.metric("Max Drawdown", f"{performance_metrics.get('max_drawdown', 0):.2f}%")
        with col4:
            st.metric("Sharpe Ratio", f"{performance_metrics.get('sharpe_ratio', 0):.2f}")

except Exception as e:
    st.error(f"An error occurred: {str(e)}")
    st.error("Please check your symbol and try again.")

# Footer
st.markdown("---")
st.markdown("### About")
st.markdown("""
This dashboard implements 10 comprehensive trading strategies based on technical analysis:

**PUT Strategies (🟥):**
- E1: First Red Candle
- E2: GAP Floor Break  
- E3: Daily Hanger
- E4: 4-Step Model

**CALL Strategies (🟩):**
- E5: Strong Fall
- E6: Normal Fall
- E7: Bearish GAP Up
- E8: GAP Up
- E9: Strong Floor
- E10: PM40

Each strategy can be individually configured and activated. The dashboard provides real-time signal detection with visual indicators on the chart.
""")
